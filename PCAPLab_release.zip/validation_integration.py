"""Adapter between participant #2's protocol hypotheses and participant #3's verifier.

The adapter validates each hypothesis evidence item by decoding the raw message bytes
with participant #3's FieldRule implementation and comparing them with the expected
value recorded in participant #2's action-journal evidence. This is evidence-level
validation, not proof that a field has that meaning for every possible message.
"""
from __future__ import annotations

import math
from collections import Counter
from typing import Any, Mapping

from verification import FieldRule, MessageSample, verify_corpus

_STATUSES = ("PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE")


def _candidate_rules(candidate: Mapping[str, Any], evidence: Mapping[str, Any]) -> list[tuple[str, FieldRule]]:
    """Build participant #3 checks for a single piece of candidate evidence."""
    kind = str(candidate.get("kind", ""))
    candidate_id = str(candidate.get("candidate_id", "candidate"))
    field_name = str(candidate.get("field", "field"))
    offset = int(candidate.get("offset", 0))
    message_id = str(evidence.get("message_id", "message"))
    expected = evidence.get("expected")
    base_id = f"{candidate_id}:{message_id}"
    description = str(candidate.get("title") or f"Проверка поля {field_name}")

    if offset < 0:
        raise ValueError("offset должен быть неотрицательным")

    if kind == "numeric":
        if isinstance(expected, bool) or not isinstance(expected, (int, float)):
            raise ValueError("для числового кандидата ожидается число")
        width = int(candidate.get("width") or 0)
        if width < 1:
            raise ValueError("у числового кандидата отсутствует корректная ширина")
        scale = float(candidate.get("scale", 1) or 1)
        if not math.isfinite(scale) or scale == 0:
            raise ValueError("scale должен быть конечным ненулевым числом")
        encoded_value = float(expected) * scale
        rounded = round(encoded_value)
        if not math.isclose(encoded_value, rounded, rel_tol=0, abs_tol=1e-6):
            raise ValueError("ожидаемое значение с учётом scale не представляется целым числом байтов")
        # Participant #3's uint rule checks the exact encoded bytes as an unsigned
        # integer. Convert signed negative expectations to the same two's-complement
        # byte pattern when the candidate explicitly declares signed=True.
        if candidate.get("signed") and rounded < 0:
            rounded %= 256 ** width
        byte_order = str(candidate.get("byte_order", "big"))
        rule = FieldRule(
            rule_id=f"{base_id}:numeric",
            description=f"{description}; ожидаемое значение {expected!r} (scale={scale:g})",
            kind="uint", offset=offset, size=width,
            byte_order=byte_order if byte_order in ("big", "little") else "big",
            equals=int(rounded),
        )
        return [("numeric_value", rule)]

    if kind == "boolean":
        if not isinstance(expected, bool):
            raise ValueError("для логического кандидата ожидается true/false")
        width = int(candidate.get("width") or 1)
        if width != 1:
            raise ValueError("логическое поле в текущей гипотезе должно занимать один байт")
        rule = FieldRule(
            rule_id=f"{base_id}:boolean",
            description=f"{description}; 0=false, 1=true",
            kind="uint", offset=offset, size=1,
            byte_order="big", equals=1 if expected else 0,
        )
        return [("boolean_value", rule)]

    if kind == "text":
        if not isinstance(expected, str):
            raise ValueError("для текстового кандидата ожидается строка")
        encoded = expected.encode("utf-8")
        if not encoded:
            raise ValueError("пустая строка не поддерживается как доказательство поля")
        text_rule = FieldRule(
            rule_id=f"{base_id}:text",
            description=f"{description}; UTF-8 текст",
            kind="hex", offset=offset, size=len(encoded), equals=encoded.hex(),
        )
        rules = [("text_bytes", text_rule)]
        prefix_offset = candidate.get("length_prefix_offset")
        if prefix_offset is not None:
            prefix_offset = int(prefix_offset)
            if prefix_offset < 0:
                raise ValueError("length_prefix_offset должен быть неотрицательным")
            prefix_rule = FieldRule(
                rule_id=f"{base_id}:text_length",
                description=f"Длина UTF-8 поля {field_name} в байтах",
                kind="uint", offset=prefix_offset, size=1, equals=len(encoded),
            )
            rules.append(("text_length_prefix", prefix_rule))
        return rules

    raise ValueError(f"неподдерживаемый тип гипотезы: {kind!r}")


def _combined_status(checks: list[dict[str, Any]]) -> str:
    statuses = [str(check.get("status")) for check in checks]
    if "FAIL" in statuses:
        return "FAIL"
    if "UNKNOWN" in statuses:
        return "UNKNOWN"
    if statuses and all(status == "NOT_APPLICABLE" for status in statuses):
        return "NOT_APPLICABLE"
    return "PASS" if statuses else "UNKNOWN"


def validate_protocol_analysis(
    protocol_analysis: Mapping[str, Any],
    *,
    source_id: str,
    source_sha256: str,
) -> dict[str, Any]:
    """Validate participant #2 candidate evidence with participant #3's verifier."""
    if (not source_sha256 or len(source_sha256.strip()) != 64
            or any(ch not in "0123456789abcdefABCDEF" for ch in source_sha256.strip())):
        raise ValueError("В отчёте PCAP отсутствует корректный SHA-256 исходного файла")

    messages = protocol_analysis.get("messages") or []
    candidates = protocol_analysis.get("hypothesis_candidates") or []
    messages_by_id = {str(m.get("message_id")): m for m in messages if m.get("message_id") is not None}

    result_groups: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []
    check_status_counts: Counter[str] = Counter()
    evidence_status_counts: Counter[str] = Counter()
    candidate_evidence_total = 0
    candidate_evidence_checked = 0
    candidate_evidence_skipped = 0

    for candidate in candidates:
        candidate = dict(candidate)
        candidate_evidence = candidate.get("evidence") or []
        group = {
            "candidate_id": candidate.get("candidate_id"),
            "field": candidate.get("field"),
            "kind": candidate.get("kind"),
            "title": candidate.get("title"),
            "strength": candidate.get("strength"),
            "hypothesis_support_rate": candidate.get("support_rate"),
            "offset": candidate.get("offset"),
            "width": candidate.get("width"),
            "evidence": [],
            "summary": {name: 0 for name in (*_STATUSES, "SKIPPED")},
        }

        for evidence in candidate_evidence:
            evidence = dict(evidence)
            candidate_evidence_total += 1
            message_id = str(evidence.get("message_id", ""))
            message = messages_by_id.get(message_id)
            if message is None:
                candidate_evidence_skipped += 1
                group["summary"]["SKIPPED"] += 1
                diagnostics.append({
                    "code": "candidate_evidence_message_missing",
                    "candidate_id": candidate.get("candidate_id"),
                    "message_id": message_id,
                    "message": "В анализе нет сообщения, указанного в доказательстве гипотезы.",
                })
                group["evidence"].append({
                    "message_id": message_id,
                    "action_id": evidence.get("action_id"),
                    "expected": evidence.get("expected"),
                    "status": "SKIPPED",
                    "checks": [],
                })
                continue

            try:
                payload = bytes.fromhex(str(message.get("hex_data", "")))
                packet_numbers = tuple(int(number) for number in (message.get("source_frames") or []))
                sample = MessageSample(
                    source_id=source_id,
                    source_sha256=source_sha256,
                    message_id=message_id,
                    payload=payload,
                    direction=str(message.get("direction") or "unknown"),
                    packet_numbers=packet_numbers,
                    complete=bool(message.get("complete", True)),
                    ambiguous=bool(message.get("ambiguous", False)),
                    notes="Сообщение извлечено участником № 2 из восстановленного потока участника № 1.",
                )
                rules = _candidate_rules(candidate, evidence)
            except (ValueError, TypeError, OverflowError) as exc:
                candidate_evidence_skipped += 1
                group["summary"]["SKIPPED"] += 1
                diagnostics.append({
                    "code": "candidate_evidence_not_verifiable",
                    "candidate_id": candidate.get("candidate_id"),
                    "message_id": message_id,
                    "message": str(exc),
                })
                group["evidence"].append({
                    "message_id": message_id,
                    "action_id": evidence.get("action_id"),
                    "expected": evidence.get("expected"),
                    "status": "SKIPPED",
                    "reason": str(exc),
                    "checks": [],
                })
                continue

            checks: list[dict[str, Any]] = []
            for check_name, rule in rules:
                report = verify_corpus(
                    [sample], [rule],
                    metadata={"candidate_id": candidate.get("candidate_id"), "action_id": evidence.get("action_id")},
                ).to_dict()
                check = report["results"][0]
                enriched = {
                    "check_name": check_name,
                    **check,
                }
                checks.append(enriched)
                check_status_counts[check["status"]] += 1

            evidence_status = _combined_status(checks)
            candidate_evidence_checked += 1
            evidence_status_counts[evidence_status] += 1
            group["summary"][evidence_status] += 1
            group["evidence"].append({
                "message_id": message_id,
                "action_id": evidence.get("action_id"),
                "expected": evidence.get("expected"),
                "participant_2_observed": evidence.get("observed", evidence.get("observed_hex")),
                "participant_2_matches": evidence.get("matches"),
                "status": evidence_status,
                "status_label": {
                    "PASS": "Проверка байтов подтвердила это доказательство",
                    "FAIL": "Проверка байтов обнаружила несоответствие ожиданию",
                    "UNKNOWN": "Недостаточно данных для однозначной проверки",
                    "NOT_APPLICABLE": "Правило не применяется к сообщению",
                }.get(evidence_status, evidence_status),
                "checks": checks,
            })

        result_groups.append(group)

    summary = {
        "candidates_total": len(candidates),
        "candidate_evidence_total": candidate_evidence_total,
        "candidate_evidence_checked": candidate_evidence_checked,
        "candidate_evidence_skipped": candidate_evidence_skipped,
        "checks_total": sum(check_status_counts.values()),
        **{status: check_status_counts[status] for status in _STATUSES},
        "evidence_PASS": evidence_status_counts["PASS"],
        "evidence_FAIL": evidence_status_counts["FAIL"],
        "evidence_UNKNOWN": evidence_status_counts["UNKNOWN"],
        "evidence_NOT_APPLICABLE": evidence_status_counts["NOT_APPLICABLE"],
    }
    return {
        "schema_version": "0.1",
        "analysis_type": "protocol_hypothesis_evidence_validation",
        "source": {"source_id": source_id, "source_sha256": source_sha256},
        "summary": summary,
        "candidate_results": result_groups,
        "diagnostics": diagnostics,
        "notes": [
            "Проверяются отдельные доказательства гипотез участника № 2 по исходным байтам сообщений.",
            "PASS означает совпадение конкретного значения с байтами данного сообщения, а не доказательство смысла поля для всего протокола.",
            "Для текстовых гипотез отдельно проверяются UTF-8 байты и байт длины, если он указан.",
            "При отсутствии сообщения или неподдерживаемом типе доказательства результат помечается как SKIPPED.",
        ],
    }
