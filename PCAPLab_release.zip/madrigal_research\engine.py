"""Простые гипотезы о полях бинарного протокола MADRIGAL.

Вход: JSON-отчёт madrigal_net и строки action_journal.csv.
Модуль не читает PCAP и не восстанавливает TCP: он разбирает уже собранные
непрерывные байты потока. Гипотезы — подсказки, а не доказательство формата.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

MAGIC = bytes.fromhex("A6 5C")
HEADER_SIZE = 8
DEFAULT_DEVICE_PORT = 46123


def _json_dict(value: Any) -> dict:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            pass
    return {}


def _timestamp(value: Any) -> float | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return datetime.fromisoformat(value.strip().replace("Z", "+00:00")).timestamp()
    except (ValueError, OverflowError):
        return None


def _basename(value: Any) -> str:
    return str(value or "").replace("\\", "/").rstrip("/").split("/")[-1].casefold()


def load_action_journal(path: str | Path) -> list[dict[str, Any]]:
    """Загрузить CSV-журнал и разобрать JSON-колонки parameters/observed_result."""
    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    for row in rows:
        row["parameters"] = _json_dict(row.get("parameters"))
        row["observed_result"] = _json_dict(row.get("observed_result"))
    return rows


def _data_runs(ranges: Sequence[Mapping[str, Any]]) -> tuple[list[dict], list[dict]]:
    """Склеить только соседние известные data-диапазоны; gap/conflict не заполнять."""
    runs, diagnostics, current = [], [], None
    for item in sorted(ranges, key=lambda r: int(r.get("offset_start", 0))):
        start = int(item.get("offset_start", 0))
        end = int(item.get("offset_end", start))
        if item.get("kind") != "data":
            if current:
                runs.append(current)
                current = None
            diagnostics.append({
                "code": "stream_range_not_known_data", "kind": item.get("kind"),
                "offset_start": start, "offset_end": end,
                "message": "Диапазон gap/conflict пропущен; неизвестные байты не восстанавливались.",
            })
            continue
        try:
            raw = bytes.fromhex(str(item.get("value_hex", "")))
        except ValueError:
            raw = b""
        if end < start or len(raw) != end - start:
            if current:
                runs.append(current)
                current = None
            diagnostics.append({"code": "invalid_data_range", "offset_start": start, "offset_end": end})
            continue
        if current and start == current["end"]:
            current["data"] += raw
            current["end"] = end
            current["ranges"].append(item)
        else:
            if current:
                runs.append(current)
            current = {"start": start, "end": end, "data": raw, "ranges": [item]}
    if current:
        runs.append(current)
    return runs, diagnostics


def _frames_for_range(run: Mapping[str, Any], start: int, end: int) -> list[int]:
    frames = set()
    for item in run["ranges"]:
        if int(item.get("offset_start", 0)) < end and int(item.get("offset_end", 0)) > start:
            for source in item.get("provenance", []) or []:
                if source.get("frame_no") is not None:
                    frames.add(int(source["frame_no"]))
    return sorted(frames)


def _direction(frames: list[dict], session: Mapping[str, Any], direction: int, device_port: int) -> str:
    for packet in frames:
        if packet.get("dst_port") == device_port:
            return "client_to_device"
        if packet.get("src_port") == device_port:
            return "device_to_client"
    initiator = session.get("initiator")
    if initiator in ("A", "B"):
        from_initiator = (direction == 0 and initiator == "A") or (direction == 1 and initiator == "B")
        return "client_to_device" if from_initiator else "device_to_client"
    return f"direction_{direction}_initiator_unknown"


def extract_messages(report: Mapping[str, Any], device_port: int = DEFAULT_DEVICE_PORT) -> dict[str, Any]:
    """Разобрать A6 5C + длину тела (2 байта big-endian) + заголовок 8 байт."""
    capture = dict(report.get("capture") or {})
    messages, diagnostics = [], []
    for session in report.get("sessions", []) or []:
        packet_by_frame = {}
        for packet in session.get("packets", []) or []:
            try:
                packet_by_frame[int(packet["frame_no"])] = packet
            except (KeyError, TypeError, ValueError):
                continue
        for direction_info in session.get("directions", []) or []:
            stream = direction_info.get("stream") or {}
            direction = int(direction_info.get("direction", stream.get("direction", 0)))
            runs, run_diagnostics = _data_runs(stream.get("ranges", []) or [])
            diagnostics += [dict(d, session_id=session.get("session_id"), direction_code=direction) for d in run_diagnostics]
            for run in runs:
                data, cursor = run["data"], 0
                while cursor < len(data):
                    marker = data.find(MAGIC, cursor)
                    if marker < 0:
                        break
                    cursor = marker
                    if len(data) - cursor < 4:
                        diagnostics.append({"code": "incomplete_frame_header", "session_id": session.get("session_id"), "offset_start": run["start"] + cursor})
                        break
                    body_length = int.from_bytes(data[cursor + 2:cursor + 4], "big")
                    frame_length = HEADER_SIZE + body_length
                    if len(data) - cursor < frame_length:
                        diagnostics.append({"code": "incomplete_frame_body", "session_id": session.get("session_id"), "offset_start": run["start"] + cursor, "expected_length": frame_length, "available_length": len(data) - cursor})
                        break
                    start = run["start"] + cursor
                    end = start + frame_length
                    raw = data[cursor:cursor + frame_length]
                    source_frames = _frames_for_range(run, start, end)
                    packets = [packet_by_frame[n] for n in source_frames if n in packet_by_frame]
                    times = [float(p["timestamp"]) for p in packets if p.get("timestamp") is not None]
                    seed = f"{capture.get('capture_id')}|{session.get('session_id')}|{direction}|{start}"
                    messages.append({
                        "message_id": hashlib.sha1(seed.encode()).hexdigest()[:12],
                        "capture_id": capture.get("capture_id"),
                        "capture_name": capture.get("source_name") or Path(str(capture.get("source_path", "capture"))).name,
                        "session_id": session.get("session_id"), "direction_code": direction,
                        "direction": _direction(packets, session, direction, device_port),
                        "stream_offset_start": start, "stream_offset_end": end,
                        "byte_length": len(raw), "declared_body_length": body_length,
                        "transaction_id_hex": raw[4:6].hex(" ").upper(),
                        "opcode_hex": raw[6:8].hex(" ").upper(),
                        "hex_data": raw.hex(" ").upper(), "source_frames": source_frames,
                        "timestamp_start": min(times) if times else None,
                        "timestamp_end": max(times) if times else None, "action_matches": [],
                    })
                    cursor += frame_length
            for item in stream.get("diagnostics", []) or []:
                diagnostics.append({**dict(item), "session_id": session.get("session_id"), "direction_code": direction})
        diagnostics += [dict(d, session_id=session.get("session_id")) for d in session.get("diagnostics", []) or []]
    messages.sort(key=lambda m: (m["timestamp_start"] if m["timestamp_start"] is not None else math.inf, m["stream_offset_start"]))
    return {"capture": capture, "messages": messages, "diagnostics": diagnostics,
            "summary": {"messages_total": len(messages), "diagnostics_total": len(diagnostics)}}


def associate_actions(messages: Sequence[Mapping[str, Any]], action_rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Привязать действия по совпадению имени PCAP и пересечению временных интервалов."""
    actions = []
    for row in action_rows:
        action = dict(row)
        action["parameters"] = _json_dict(action.get("parameters"))
        action["observed_result"] = _json_dict(action.get("observed_result"))
        action["_capture"] = _basename(action.get("capture"))
        action["_start"] = _timestamp(action.get("start_utc"))
        action["_end"] = _timestamp(action.get("end_utc"))
        actions.append(action)
    result = []
    for original in messages:
        message = dict(original)
        matches = []
        start, end = message.get("timestamp_start"), message.get("timestamp_end")
        for action in actions:
            if action["_capture"] != _basename(message.get("capture_name")):
                continue
            if start is None or end is None or action["_start"] is None or action["_end"] is None:
                continue
            if float(start) <= action["_end"] and float(end) >= action["_start"]:
                matches.append({k: action.get(k) for k in (
                    "action_id", "action", "session", "start_utc", "end_utc", "parameters", "observed_result")})
                matches[-1]["correlation_method"] = "пересечение временных интервалов; причинность не доказана"
        message["action_matches"] = matches
        result.append(message)
    return result


def _samples(messages: Sequence[Mapping[str, Any]]) -> list[dict]:
    samples = []
    for message in messages:
        if message.get("direction") != "client_to_device":
            continue
        try:
            raw = bytes.fromhex(str(message.get("hex_data", "")))
        except ValueError:
            continue
        for action in message.get("action_matches", []) or []:
            for field, expected in (action.get("parameters") or {}).items():
                samples.append({"message_id": message.get("message_id"), "action_id": action.get("action_id"),
                                "field": str(field), "expected": expected, "raw": raw})
    # Один пример на комбинацию сообщения, действия и поля.
    unique = {}
    for sample in samples:
        key = (sample["message_id"], sample["action_id"], sample["field"])
        unique[key] = sample
    return list(unique.values())


def _candidate_id(*parts: Any) -> str:
    return "H-" + hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:10].upper()


def _rate_candidate(field: str, kind: str, offset: int, width: int, samples: list[dict], decode) -> dict | None:
    evidence, support = [], 0
    for sample in samples:
        observed = decode(sample["raw"], offset, width)
        expected = sample["expected"]
        matches = observed is not None and observed == expected
        support += int(matches)
        evidence.append({"message_id": sample["message_id"], "action_id": sample["action_id"],
                         "expected": expected, "observed": observed, "matches": matches})
    if not support or not evidence:
        return None
    rate = support / len(evidence)
    return {"candidate_id": _candidate_id(kind, field, offset, width),
            "title": f"{field}: возможное поле с байта {offset}", "field": field, "kind": kind,
            "offset": offset, "width": width, "support_count": support, "sample_count": len(evidence),
            "support_rate": round(rate, 3), "strength": "strong" if rate == 1 and support >= 3 else "moderate" if rate >= .8 and support >= 2 else "weak",
            "evidence": evidence}


def generate_hypothesis_candidates(messages: Sequence[Mapping[str, Any]], max_candidates_per_field: int = 8) -> list[dict[str, Any]]:
    """Искать простые big-endian числа, байты 0/1 и UTF-8 строки в размеченных сообщениях."""
    samples = _samples(messages)
    by_field: dict[str, list[dict]] = {}
    for sample in samples:
        by_field.setdefault(sample["field"], []).append(sample)
    candidates = []
    for field, items in by_field.items():
        values = [s["expected"] for s in items]
        max_len = max((len(s["raw"]) for s in items), default=0)

        # Числа: без знака, big-endian; scale нужен, например, для градусов * 100.
        if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
            found = []
            for width in (1, 2, 4):
                for offset in range(max_len - width + 1):
                    for scale in (1, 10, 100, 1000):
                        def decode(raw, pos, size, scale=scale):
                            if pos + size > len(raw): return None
                            return int.from_bytes(raw[pos:pos + size], "big") / scale
                        candidate = _rate_candidate(field, "numeric", offset, width, items, decode)
                        if candidate:
                            candidate.update({"byte_order": "big", "signed": False, "scale": scale})
                            candidate["candidate_id"] = _candidate_id("numeric", field, offset, width, scale)
                            found.append(candidate)
            found.sort(key=lambda c: (-c["support_rate"], -c["support_count"], c["width"], c["offset"], c["scale"]))
            candidates.extend(found[:max_candidates_per_field])

        # Boolean: один байт 0=false, 1=true.
        elif all(isinstance(v, bool) for v in values):
            for offset in range(max_len):
                def decode(raw, pos, _width):
                    if pos >= len(raw) or raw[pos] not in (0, 1): return None
                    return raw[pos] == 1
                candidate = _rate_candidate(field, "boolean", offset, 1, items, decode)
                if candidate:
                    candidate["encoding"] = "0=false, 1=true"
                    candidates.append(candidate)

        # Текст: найти строку в байтах и проверить, совпадает ли байт перед ней с её длиной.
        elif all(isinstance(v, str) for v in values):
            offsets = set()
            for sample in items:
                encoded = sample["expected"].encode("utf-8")
                if encoded:
                    start = 0
                    while True:
                        pos = sample["raw"].find(encoded, start)
                        if pos < 0: break
                        offsets.add(pos)
                        start = pos + 1
            for offset in sorted(offsets):
                def decode(raw, pos, _width):
                    if pos >= len(raw): return None
                    try: return raw[pos:].decode("utf-8")
                    except UnicodeDecodeError: return None
                # Проверяем только конкретное ожидаемое значение, чтобы не зависеть от хвоста сообщения.
                evidence, support = [], 0
                for sample in items:
                    expected = sample["expected"].encode("utf-8")
                    text_ok = sample["raw"][offset:offset + len(expected)] == expected
                    prefix_ok = offset > 0 and sample["raw"][offset - 1] == len(expected)
                    match = text_ok and prefix_ok
                    support += int(match)
                    evidence.append({"message_id": sample["message_id"], "action_id": sample["action_id"],
                                     "expected": sample["expected"], "observed_hex": expected.hex(" ").upper(),
                                     "text_matches": text_ok, "length_prefix_matches": prefix_ok, "matches": match})
                if support:
                    rate = support / len(evidence)
                    candidates.append({"candidate_id": _candidate_id("text", field, offset),
                        "title": f"{field}: возможный UTF-8 текст с байта {offset}", "field": field, "kind": "text",
                        "offset": offset, "width": None, "encoding": "utf-8", "length_prefix_offset": offset - 1,
                        "length_prefix_unit": "bytes", "support_count": support, "sample_count": len(evidence),
                        "support_rate": round(rate, 3), "strength": "strong" if rate == 1 and support >= 3 else "moderate" if rate >= .8 and support >= 2 else "weak",
                        "evidence": evidence})

    candidates.sort(key=lambda c: (0 if c["strength"] == "strong" else 1 if c["strength"] == "moderate" else 2,
                                   -c["support_rate"], -c["support_count"], c["field"], c["offset"]))
    return candidates


def verify_candidate(candidate: Mapping[str, Any], messages: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Повторно проверить сохранённую гипотезу на доступных размеченных сообщениях."""
    field, kind = str(candidate.get("field", "")), str(candidate.get("kind", ""))
    samples = [s for s in _samples(messages) if s["field"] == field and (
        (kind == "numeric" and isinstance(s["expected"], (int, float)) and not isinstance(s["expected"], bool)) or
        (kind == "boolean" and isinstance(s["expected"], bool)) or (kind == "text" and isinstance(s["expected"], str)))]
    offset = int(candidate.get("offset", 0))
    width = int(candidate.get("width") or 1)
    evidence, support = [], 0
    for sample in samples:
        raw, expected = sample["raw"], sample["expected"]
        field_hex = None
        observed = None
        if kind == "numeric" and offset + width <= len(raw):
            field_raw = raw[offset:offset + width]
            field_hex = field_raw.hex(" ").upper()
            scale = float(candidate.get("scale", 1))
            observed = int.from_bytes(field_raw, str(candidate.get("byte_order", "big")), signed=bool(candidate.get("signed", False))) / scale
            matched = math.isclose(observed, float(expected), abs_tol=1e-9)
        elif kind == "boolean":
            observed = raw[offset] == 1 if offset < len(raw) and raw[offset] in (0, 1) else None
            matched = observed is expected
        elif kind == "text":
            encoded = str(expected).encode("utf-8")
            prefix = candidate.get("length_prefix_offset")
            matched = raw[offset:offset + len(encoded)] == encoded
            if prefix is not None:
                matched = matched and 0 <= int(prefix) < len(raw) and raw[int(prefix)] == len(encoded)
            observed, field_hex = (str(expected) if matched else None), encoded.hex(" ").upper()
        else:
            raise ValueError(f"Unsupported candidate kind: {kind}")
        support += int(matched)
        evidence.append({"message_id": sample["message_id"], "action_id": sample["action_id"],
                         "expected": expected, "observed": observed, "field_hex": field_hex, "matches": matched})
    total = len(evidence)
    status = "not_testable_no_labeled_samples" if not total else "supported_on_supplied_samples" if support == total else "contradicted_by_supplied_samples" if support == 0 else "partially_supported"
    return {"candidate_id": candidate.get("candidate_id"), "field": field, "status": status,
            "support_count": support, "sample_count": total,
            "support_rate": round(support / total, 3) if total else None, "evidence": evidence,
            "limitations": ["Проверены только переданные размеченные примеры; результат не доказывает смысл поля."]}


def analyze_capture_report(report: Mapping[str, Any], action_journal: Iterable[Mapping[str, Any]],
                           device_port: int = DEFAULT_DEVICE_PORT) -> dict[str, Any]:
    """Основная функция для вызова из backend/API участника № 4."""
    parsed = extract_messages(report, device_port)
    messages = associate_actions(parsed["messages"], action_journal)
    candidates = generate_hypothesis_candidates(messages)
    return {"schema_version": "0.1", "analysis_type": "protocol_hypothesis_candidates",
            "capture": parsed["capture"],
            "summary": {"messages_total": len(messages),
                        "messages_with_action_matches": sum(bool(m["action_matches"]) for m in messages),
                        "hypothesis_candidates_total": len(candidates),
                        "diagnostics_total": len(parsed["diagnostics"])},
            "messages": messages, "hypothesis_candidates": candidates,
            "diagnostics": parsed["diagnostics"],
            "notes": ["Гипотезы ищутся в сообщениях client_to_device по параметрам из журнала действий.",
                      "Совпадение времён — подсказка для корреляции, не доказательство причинности.",
                      "Формат кадра для этого набора данных: A6 5C, длина тела big-endian в байтах 2–3, заголовок 8 байт.",
                      "При gap/conflict неизвестные байты не заполняются.",
                      "Кандидаты требуют ручной проверки на дополнительных сообщениях."]}
