from pathlib import Path
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import Ether
from scapy.packet import Raw
from scapy.utils import wrpcap, wrpcapng
from madrigal_net.reader import read_capture
from madrigal_net.sessions import group_sessions
from madrigal_net.reassemble import reassemble_direction


def make_packets():
    a, b = "192.0.2.10", "192.0.2.20"
    return [
        Ether()/IP(src=a, dst=b)/TCP(sport=53000, dport=9000, seq=1000, flags="S"),
        Ether()/IP(src=b, dst=a)/TCP(sport=9000, dport=53000, seq=2000, ack=1001, flags="SA"),
        Ether()/IP(src=a, dst=b)/TCP(sport=53000, dport=9000, seq=1001, ack=2001, flags="PA")/Raw(load=b"HELLO"),
        Ether()/IP(src=b, dst=a)/TCP(sport=9000, dport=53000, seq=2001, ack=1006, flags="PA")/Raw(load=b"OK"),
    ]


def test_read_pcap_and_pcapng(tmp_path: Path):
    for extension, writer in (("pcap", wrpcap), ("pcapng", wrpcapng)):
        path = tmp_path / f"demo.{extension}"
        writer(str(path), make_packets())
        result = read_capture(path)
        assert result["stats"]["frames_total"] == 4
        assert result["stats"]["tcp_ipv4_packets"] == 4
        assert result["stats"]["tcp_payload_bytes"] == 7
        assert result["packets"][2]["payload"] == b"HELLO"


def fake_packet(frame_no, seq, payload, capture_id="capture-test", direction=0):
    return {
        "capture_id": capture_id, "frame_no": frame_no,
        "direction": direction, "payload_seq_raw": seq,
        "payload": payload,
    }


def test_reorder_and_identical_retransmission():
    ps = [fake_packet(1, 1003, b"DEF"), fake_packet(2, 1000, b"ABC"), fake_packet(3, 1000, b"ABC")]
    result = reassemble_direction(ps)
    assert all(r["kind"] == "data" for r in result["ranges"])
    assert "".join(bytes.fromhex(r["value_hex"]).decode() for r in result["ranges"]) == "ABCDEF"
    assert len(result["ranges"][0]["provenance"]) >= 1


def test_gap_not_filled_with_zeros():
    result = reassemble_direction([fake_packet(1, 1000, b"ABC"), fake_packet(2, 1006, b"XY")])
    assert [r["kind"] for r in result["ranges"]] == ["data", "gap", "data"]
    gap = result["ranges"][1]
    assert gap["length"] == 3 and gap["value"] is None


def test_conflicting_overlap_reported():
    result = reassemble_direction([fake_packet(1, 1000, b"ABCD"), fake_packet(2, 1002, b"XYEF")])
    assert any(r["kind"] == "conflict" for r in result["ranges"])
    assert any(d["code"] == "conflicting_overlap" for d in result["diagnostics"])


def test_session_marks_missing_syn_as_unknown():
    p = fake_packet(1, 1000, b"A")
    p.update({
        "endpoint_a": {"ip": "192.0.2.10", "port": 50000},
        "endpoint_b": {"ip": "192.0.2.20", "port": 9000},
        "src_ip": "192.0.2.10", "src_port": 50000,
        "dst_ip": "192.0.2.20", "dst_port": 9000,
        "syn": False, "ack": True, "fin": False, "rst": False,
        "payload_len": 1,
    })
    sessions = group_sessions([p])
    assert sessions[0]["initiator"] is None
    assert sessions[0]["start_observed"] is False
