"""Автоматические проверки модуля участника № 3.

Запуск из корневой папки проекта:
    python -m unittest discover -s tests -v
"""

import unittest

from verification import (
    FieldRule,
    MessageSample,
    check_one,
    report_is_current,
    verify_corpus,
)


class VerificationTests(unittest.TestCase):
    """Проверяем обычные результаты и пограничные случаи."""

    def setUp(self):
        # Короткое сообщение для большинства тестов.
        self.sample = MessageSample(
            source_id="captures/test.pcapng",
            source_sha256="source-hash-123",
            message_id="session-1:message-1",
            payload=bytes.fromhex("00 50 AA BB"),
            direction="client_to_server",
            packet_numbers=(12, 13),
        )
        self.rule = FieldRule(
            rule_id="first_field",
            description="Первые два байта содержат число 80",
            kind="uint",
            offset=0,
            size=2,
            byte_order="big",
            equals=80,
        )

    def test_matching_value_passes_and_keeps_evidence(self):
        result = check_one(self.sample, self.rule)

        self.assertEqual(result.status, "PASS")
        self.assertEqual(result.observed, 80)
        self.assertEqual(result.evidence_hex, "00 50")
        self.assertEqual(result.status_label, "Условие выполнено")
        self.assertEqual(result.packet_numbers, [12, 13])

    def test_different_value_is_a_counterexample(self):
        wrong_rule = FieldRule(
            rule_id="wrong_expectation",
            description="Проверка другого значения",
            kind="uint",
            offset=0,
            size=2,
            byte_order="big",
            equals=81,
        )

        result = check_one(self.sample, wrong_rule)

        self.assertEqual(result.status, "FAIL")
        self.assertEqual(result.observed, 80)
        self.assertEqual(result.status_label, "Найдено несоответствие правилу")

    def test_missing_bytes_has_human_readable_label(self):
        short_sample = MessageSample(
            source_id=self.sample.source_id,
            source_sha256=self.sample.source_sha256,
            message_id="short-message",
            payload=bytes.fromhex("00"),
        )

        result = check_one(short_sample, self.rule)

        self.assertEqual(result.status, "UNKNOWN")
        self.assertEqual(result.status_label, "Не хватает байтов для проверки")
        self.assertIn("длина сообщения", result.explanation)

    def test_incomplete_and_ambiguous_messages_are_not_guessed(self):
        incomplete = MessageSample(
            source_id=self.sample.source_id,
            source_sha256=self.sample.source_sha256,
            message_id="incomplete-message",
            payload=self.sample.payload,
            complete=False,
        )
        ambiguous = MessageSample(
            source_id=self.sample.source_id,
            source_sha256=self.sample.source_sha256,
            message_id="ambiguous-message",
            payload=self.sample.payload,
            ambiguous=True,
        )

        incomplete_result = check_one(incomplete, self.rule)
        ambiguous_result = check_one(ambiguous, self.rule)

        self.assertEqual(incomplete_result.status, "UNKNOWN")
        self.assertEqual(
            incomplete_result.status_label,
            "Сообщение неполное - проверка невозможна",
        )
        self.assertEqual(ambiguous_result.status, "UNKNOWN")
        self.assertEqual(ambiguous_result.status_label, "Нельзя сделать однозначный вывод")
        self.assertIsNone(incomplete_result.observed)
        self.assertIsNone(ambiguous_result.observed)

    def test_direction_and_disabled_rule_are_not_applicable(self):
        direction_rule = FieldRule(
            rule_id="server_only",
            description="Только направление от сервера",
            kind="uint",
            offset=0,
            size=2,
            equals=80,  # the condition is irrelevant when direction is not applicable
            scope_direction="server_to_client",
        )
        disabled_rule = FieldRule(
            rule_id="disabled",
            description="Отключённое правило",
            kind="uint",
            equals=0,  # условие не выполняется, поскольку правило отключено
            enabled=False,
        )

        self.assertEqual(check_one(self.sample, direction_rule).status, "NOT_APPLICABLE")
        self.assertEqual(check_one(self.sample, disabled_rule).status, "NOT_APPLICABLE")

    def test_corpus_summary_and_report_freshness(self):
        report = verify_corpus([self.sample], [self.rule])
        data = report.to_dict()

        self.assertEqual(data["summary"]["TOTAL"], 1)
        self.assertEqual(data["summary"]["PASS"], 1)
        self.assertTrue(report_is_current(
            data,
            [self.rule],
            {self.sample.source_id: self.sample.source_sha256},
        ))
        self.assertFalse(report_is_current(
            data,
            [self.rule],
            {self.sample.source_id: "different-source-hash"},
        ))


if __name__ == "__main__":
    unittest.main()
