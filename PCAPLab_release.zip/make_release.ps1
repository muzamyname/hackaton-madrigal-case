$ErrorActionPreference = 'Stop'

# Create a source archive while excluding virtual environments, caches,
# generated artifacts, local backups, and existing ZIP files.
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$mainPath = Join-Path $projectRoot 'main.py'
if (-not (Test-Path $mainPath)) {
    throw 'main.py was not found. Save this script in the project root next to main.py.'
}

$projectName = 'PCAPLab'
$releasePath = Join-Path (Split-Path -Parent $projectRoot) 'PCAPLab_release.zip'
$stageRoot = Join-Path $env:TEMP ('PCAPLab_release_' + [guid]::NewGuid().ToString('N'))
$stageProject = Join-Path $stageRoot $projectName

New-Item -ItemType Directory -Path $stageProject -Force | Out-Null

Write-Host 'Copying project files...' -ForegroundColor Cyan
& robocopy $projectRoot $stageProject /E /R:1 /W:1 `
    /XD '.venv' '.git' '__pycache__' '.pytest_cache' 'artifacts' 'node_modules' `
    /XF '*.zip' '*.pyc' 'main_backup.py' 'main_before_module2.py' 'index_backup.html' 'PCAPLab_release.zip' | Out-Null
$copyCode = $LASTEXITCODE
if ($copyCode -gt 7) {
    Remove-Item $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
    throw "Robocopy failed with exit code $copyCode. The release archive was not created."
}

if (Test-Path $releasePath) {
    Remove-Item $releasePath -Force
}

Write-Host 'Creating ZIP archive...' -ForegroundColor Cyan
Compress-Archive -Path (Join-Path $stageProject '*') -DestinationPath $releasePath -CompressionLevel Optimal
Remove-Item $stageRoot -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ''
Write-Host 'Done! Archive created:' -ForegroundColor Green
Write-Host $releasePath -ForegroundColor Green
Write-Host 'Check that all module folders and the updated static/index.html are included.' -ForegroundColor Yellow
