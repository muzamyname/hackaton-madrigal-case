"""Read Ethernet/IPv4/TCP packets from PCAP or PCAPNG using Scapy."""
from __future__ import annotations

import hashlib
import uuid
from pathlib import Path
from typing import Any, Iterator

from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import Ether
from scapy.utils import PcapReader


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def read_capture(path: str | Path) -> dict[str, Any]:
    """Parse a capture and return packet metadata plus raw payload bytes.

    A new capture_id is assigned per import. source_sha256 identifies identical
    source files but is deliberately NOT used to merge imports.
    """
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Capture file not found: {source}")

    capture_id = str(uuid.uuid4())
    source_hash = sha256_file(source)
    stats = {
        "frames_total": 0,
        "ethernet_frames": 0,
        "ipv4_packets": 0,
        "tcp_ipv4_packets": 0,
        "tcp_payload_bytes": 0,
        "truncated_frames": 0,
        "non_ipv4_frames": 0,
        "non_tcp_ipv4_packets": 0,
    }
    packets: list[dict[str, Any]] = []

    try:
        with PcapReader(str(source)) as reader:
            for frame_no, packet in enumerate(reader, start=1):
                stats["frames_total"] += 1
                try:
                    captured_len = len(bytes(packet))
                except Exception:
                    captured_len = None
                wire_len = getattr(packet, "wirelen", None)
                truncated = (
                    isinstance(wire_len, int)
                    and captured_len is not None
                    and wire_len > captured_len
                )
                if truncated:
                    stats["truncated_frames"] += 1

                if Ether not in packet:
                    # The case specifies Ethernet captures; retain count but skip
                    # unsupported link-layer formats rather than misparse them.
                    stats["non_ipv4_frames"] += 1
                    continue
                stats["ethernet_frames"] += 1

                if IP not in packet:
                    stats["non_ipv4_frames"] += 1
                    continue
                stats["ipv4_packets"] += 1
                if TCP not in packet:
                    stats["non_tcp_ipv4_packets"] += 1
                    continue

                ip = packet[IP]
                tcp = packet[TCP]
                
                payload = bytes(tcp.payload)

                # Определяем IP-заголовок, расположенный перед TCP.
                ip = tcp.underlayer

                ip_total_length = getattr(ip, "len", None)
                ip_header_words = getattr(ip, "ihl", None)
                tcp_header_words = getattr(tcp, "dataofs", None)

                # Ограничиваем payload реальной длиной IP-пакета.
                if (
                    ip_total_length is not None
                    and ip_header_words is not None
                    and tcp_header_words is not None
                ):
                    ip_header_length = int(ip_header_words) * 4
                    tcp_header_length = int(tcp_header_words) * 4

                    expected_payload_length = (
                        int(ip_total_length)
                        - ip_header_length
                        - tcp_header_length
                    )

                    payload = payload[:max(0, expected_payload_length)]

                flags = int(tcp.flags)
                src = (str(ip.src), int(tcp.sport))
                dst = (str(ip.dst), int(tcp.dport))
                endpoints = tuple(sorted((src, dst)))
                direction = 0 if src == endpoints[0] else 1
                payload_seq_raw = (int(tcp.seq) + (1 if flags & 0x02 else 0)) & 0xFFFFFFFF

                record = {
                    "capture_id": capture_id,
                    "frame_no": frame_no,
                    "timestamp": float(packet.time),
                    "src_ip": str(ip.src),
                    "src_port": int(tcp.sport),
                    "dst_ip": str(ip.dst),
                    "dst_port": int(tcp.dport),
                    "endpoint_a": {"ip": endpoints[0][0], "port": endpoints[0][1]},
                    "endpoint_b": {"ip": endpoints[1][0], "port": endpoints[1][1]},
                    "direction": direction,
                    "seq_raw": int(tcp.seq),
                    "ack_raw": int(tcp.ack),
                    "payload_seq_raw": payload_seq_raw,
                    "tcp_flags": str(tcp.flags),
                    "syn": bool(flags & 0x02),
                    "ack": bool(flags & 0x10),
                    "fin": bool(flags & 0x01),
                    "rst": bool(flags & 0x04),
                    "payload": payload,
                    "payload_len": len(payload),
                    "captured_frame_len": captured_len,
                    "wire_frame_len": wire_len if isinstance(wire_len, int) else None,
                    "possibly_truncated": bool(truncated),
                    # Checksum offloading cannot be reliably inferred from one
                    # packet alone. Do not claim checksum validity here.
                    "checksum_status": "not_assessed",
                }
                packets.append(record)
                stats["tcp_ipv4_packets"] += 1
                stats["tcp_payload_bytes"] += len(payload)
    except (EOFError, ValueError) as exc:
        raise ValueError(f"Could not parse capture '{source}': {exc}") from exc

    return {
        "capture": {
            "capture_id": capture_id,
            "source_path": str(path),  # keep the path as supplied (prefer a project-relative path)
            "source_name": source.name,
            "source_sha256": source_hash,
            "source_size_bytes": source.stat().st_size,
            "format_note": "Scapy auto-detects supported PCAP/PCAPNG formats",
        },
        "stats": stats,
        "packets": packets,
    }
