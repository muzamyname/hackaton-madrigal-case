"""Simple session grouping for a hackathon MVP.

This groups by endpoint pair and starts a new generation when a new initial SYN
is seen for a tuple that already has packets. Ambiguous midstream captures are
explicitly labelled. This is a practical first version, not a full TCP state
machine.
"""
from __future__ import annotations
from collections import defaultdict
from typing import Any


def group_sessions(packets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: list[dict[str, Any]] = []
    current_by_tuple: dict[tuple, dict[str, Any]] = {}
    generations: defaultdict[tuple, int] = defaultdict(int)

    for packet in packets:
        a = (packet["endpoint_a"]["ip"], packet["endpoint_a"]["port"])
        b = (packet["endpoint_b"]["ip"], packet["endpoint_b"]["port"])
        key = (a, b)
        current = current_by_tuple.get(key)
        initial_syn = packet["syn"] and not packet["ack"]

        should_start = current is None
        if current is not None and initial_syn and current["packets"]:
            should_start = True
            current["diagnostics"].append({
                "code": "tuple_reused_or_repeated_syn",
                "severity": "warning",
                "frame_no": packet["frame_no"],
                "message": "A new initial SYN appeared for a tuple already in use; session boundary may be ambiguous.",
            })
        if current is not None and current.get("closed_by_rst", False):
            should_start = True

        if should_start:
            generations[key] += 1
            sid = f"{packet['capture_id'][:8]}-{generations[key]:04d}"
            current = {
                "session_id": sid,
                "capture_id": packet["capture_id"],
                "endpoint_a": {"ip": a[0], "port": a[1]},
                "endpoint_b": {"ip": b[0], "port": b[1]},
                "start_observed": bool(initial_syn),
                "initiator": (
                    "A" if initial_syn and packet["direction"] == 0 else
                    "B" if initial_syn and packet["direction"] == 1 else None
                ),
                "closed_by_rst": False,
                "fin_directions": set(),
                "diagnostics": [],
                "packets": [],
            }
            if not initial_syn:
                current["diagnostics"].append({
                    "code": "midstream_start",
                    "severity": "info",
                    "frame_no": packet["frame_no"],
                    "message": "Capture does not show an initial SYN for this session candidate; initiator is unknown.",
                })
            grouped.append(current)
            current_by_tuple[key] = current

        packet["session_id"] = current["session_id"]
        current["packets"].append(packet)
        if packet["fin"]:
            current["fin_directions"].add(packet["direction"])
        if packet["rst"]:
            current["closed_by_rst"] = True

    for session in grouped:
        session["closed_observed"] = bool(
            session["closed_by_rst"] or len(session["fin_directions"]) == 2
        )
        session["packet_count"] = len(session["packets"])
        session["payload_bytes"] = sum(p["payload_len"] for p in session["packets"])
        session["fin_directions"] = sorted(session["fin_directions"])
    return grouped
