import ipaddress
import unittest
import sys
import types
from unittest.mock import patch

from checksum_analysis import (
    analyze_pcap_checksums, check_ipv4_header_checksum,
    check_tcp_segment_checksum, internet_checksum,
)


def make_ipv4_header(src="192.0.2.1", dst="198.51.100.2", protocol=6, total_length=40, fragment_field=0x4000):
    header = bytearray(20)
    header[0] = 0x45  # IPv4, 20-byte header
    header[1] = 0
    header[2:4] = total_length.to_bytes(2, "big")
    header[4:6] = (0x1234).to_bytes(2, "big")
    header[6:8] = fragment_field.to_bytes(2, "big")
    header[8] = 64
    header[9] = protocol
    header[10:12] = b"\x00\x00"
    header[12:16] = ipaddress.IPv4Address(src).packed
    header[16:20] = ipaddress.IPv4Address(dst).packed
    header[10:12] = internet_checksum(bytes(header)).to_bytes(2, "big")
    return bytes(header)


def make_tcp_segment(src="192.0.2.1", dst="198.51.100.2", payload=b"hello"):
    segment = bytearray(20 + len(payload))
    segment[0:2] = (12345).to_bytes(2, "big")
    segment[2:4] = (443).to_bytes(2, "big")
    segment[4:8] = (100).to_bytes(4, "big")
    segment[8:12] = (200).to_bytes(4, "big")
    segment[12] = 0x50
    segment[13] = 0x18
    segment[14:16] = (8192).to_bytes(2, "big")
    segment[16:18] = b"\x00\x00"
    segment[18:20] = b"\x00\x00"
    segment[20:] = payload
    pseudo = (
        ipaddress.IPv4Address(src).packed
        + ipaddress.IPv4Address(dst).packed
        + b"\x00\x06"
        + len(segment).to_bytes(2, "big")
    )
    segment[16:18] = internet_checksum(pseudo + bytes(segment)).to_bytes(2, "big")
    return bytes(segment)


def make_ipv4_packet(tcp_segment, fragment_field=0x4000, corrupt_ip=False):
    src = "192.0.2.1"
    dst = "198.51.100.2"
    header = bytearray(make_ipv4_header(
        src=src, dst=dst, total_length=20 + len(tcp_segment),
        fragment_field=fragment_field,
    ))
    if corrupt_ip:
        header[8] ^= 0x01
    return bytes(header) + tcp_segment


class FakeIPLayer:
    def __init__(self, raw):
        self.raw = raw
        self.src = str(ipaddress.IPv4Address(raw[12:16])) if len(raw) >= 16 else ""
        self.dst = str(ipaddress.IPv4Address(raw[16:20])) if len(raw) >= 20 else ""

    def __bytes__(self):
        return self.raw


class FakePacket:
    def __init__(self, raw):
        self.layer = FakeIPLayer(raw)

    def __contains__(self, layer_type):
        return layer_type is FakeIPLayer

    def __getitem__(self, layer_type):
        if layer_type is FakeIPLayer:
            return self.layer
        raise KeyError(layer_type)


class FakePcapReader:
    packets = []

    def __init__(self, _path):
        self._packets = list(self.packets)

    def __iter__(self):
        return iter(self._packets)

    def close(self):
        pass



class ChecksumAnalysisTests(unittest.TestCase):
    def test_ipv4_valid_header(self):
        result = check_ipv4_header_checksum(make_ipv4_header())
        self.assertEqual(result["status"], "valid")
        self.assertIsNone(result["reason"])

    def test_ipv4_corruption_detected(self):
        header = bytearray(make_ipv4_header())
        header[8] ^= 0x01  # change TTL without updating checksum
        result = check_ipv4_header_checksum(bytes(header))
        self.assertEqual(result["status"], "invalid")
        self.assertEqual(result["reason"], "ipv4_checksum_mismatch_in_capture")

    def test_ipv4_truncated_header_is_not_assessed(self):
        result = check_ipv4_header_checksum(b"\x45" * 12)
        self.assertEqual(result["status"], "not_assessed")

    def test_tcp_valid_segment(self):
        src = ipaddress.IPv4Address("192.0.2.1").packed
        dst = ipaddress.IPv4Address("198.51.100.2").packed
        result = check_tcp_segment_checksum(src, dst, make_tcp_segment())
        self.assertEqual(result["status"], "valid")

    def test_tcp_corruption_detected(self):
        src = ipaddress.IPv4Address("192.0.2.1").packed
        dst = ipaddress.IPv4Address("198.51.100.2").packed
        segment = bytearray(make_tcp_segment())
        segment[20] ^= 0x01  # change payload without updating checksum
        result = check_tcp_segment_checksum(src, dst, bytes(segment))
        self.assertEqual(result["status"], "invalid")
        self.assertEqual(result["reason"], "tcp_checksum_mismatch_in_capture")

    def test_tcp_short_segment_is_not_assessed(self):
        result = check_tcp_segment_checksum(b"\xc0\x00\x02\x01", b"\xc6\x33\x64\x02", b"too short")
        self.assertEqual(result["status"], "not_assessed")


    def test_pcap_summary_counts_valid_invalid_and_fragmented_checksums(self):
        good_tcp = make_tcp_segment()
        bad_tcp = bytearray(good_tcp)
        bad_tcp[20] ^= 0x01
        packets = [
            FakePacket(make_ipv4_packet(good_tcp)),
            FakePacket(make_ipv4_packet(bytes(bad_tcp))),
            FakePacket(make_ipv4_packet(good_tcp, corrupt_ip=True)),
            FakePacket(make_ipv4_packet(good_tcp, fragment_field=0x2000)),
        ]
        FakePcapReader.packets = packets
        scapy_pkg = types.ModuleType("scapy")
        layers_pkg = types.ModuleType("scapy.layers")
        inet_pkg = types.ModuleType("scapy.layers.inet")
        inet_pkg.IP = FakeIPLayer
        utils_pkg = types.ModuleType("scapy.utils")
        utils_pkg.PcapReader = FakePcapReader
        modules = {
            "scapy": scapy_pkg,
            "scapy.layers": layers_pkg,
            "scapy.layers.inet": inet_pkg,
            "scapy.utils": utils_pkg,
        }
        with patch.dict(sys.modules, modules):
            result = analyze_pcap_checksums("fake.pcap", capture_name="fake.pcap")

        summary = result["summary"]
        self.assertEqual(summary["frames_total"], 4)
        self.assertEqual(summary["ipv4_packets"], 4)
        self.assertEqual(summary["ipv4_checksum"]["valid"], 3)
        self.assertEqual(summary["ipv4_checksum"]["invalid"], 1)
        self.assertEqual(summary["tcp_ipv4_packets"], 4)
        self.assertEqual(summary["tcp_checksum"]["valid"], 2)
        self.assertEqual(summary["tcp_checksum"]["invalid"], 1)
        self.assertEqual(summary["tcp_checksum"]["not_assessed"], 1)
        self.assertEqual(summary["packets_with_invalid_checksum"], 2)
        self.assertEqual(summary["diagnostics_total"], 3)

    def test_diagnostic_list_is_capped_but_totals_are_preserved(self):
        bad = bytearray(make_ipv4_header())
        bad[8] ^= 0x01
        FakePcapReader.packets = [FakePacket(bytes(bad)), FakePacket(bytes(bad))]
        scapy_pkg = types.ModuleType("scapy")
        layers_pkg = types.ModuleType("scapy.layers")
        inet_pkg = types.ModuleType("scapy.layers.inet")
        inet_pkg.IP = FakeIPLayer
        utils_pkg = types.ModuleType("scapy.utils")
        utils_pkg.PcapReader = FakePcapReader
        modules = {
            "scapy": scapy_pkg,
            "scapy.layers": layers_pkg,
            "scapy.layers.inet": inet_pkg,
            "scapy.utils": utils_pkg,
        }
        with patch.dict(sys.modules, modules):
            result = analyze_pcap_checksums("fake.pcap", max_diagnostics=1)
        self.assertEqual(result["summary"]["diagnostics_total"], 2)
        self.assertEqual(result["summary"]["diagnostics_returned"], 1)
        self.assertEqual(result["summary"]["diagnostics_omitted"], 1)


if __name__ == "__main__":
    unittest.main()
