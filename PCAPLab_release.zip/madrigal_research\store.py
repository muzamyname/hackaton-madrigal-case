"""Small JSON persistence layer for hypotheses shown/edited by the GUI."""
from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def list_hypotheses(path: str | Path) -> list[dict[str, Any]]:
    """Read saved hypothesis records; return an empty list when store is absent."""
    store = Path(path)
    if not store.exists():
        return []
    try:
        data = json.loads(store.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read hypothesis store '{store}': {exc}") from exc
    if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
        raise ValueError("Hypothesis store must be a JSON array of objects.")
    return data


def _write_atomically(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(records, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def save_hypothesis(
    path: str | Path,
    candidate: Mapping[str, Any],
    title: str,
    notes: str = "",
    author: str = "participant_2",
) -> dict[str, Any]:
    """Save a generated candidate as an editable hypothesis record."""
    clean_title = str(title).strip()
    if not clean_title:
        raise ValueError("Hypothesis title must not be empty.")
    if not candidate.get("candidate_id"):
        raise ValueError("Candidate must contain candidate_id.")

    store = Path(path)
    records = list_hypotheses(store)
    for existing in records:
        if existing.get("candidate_id") == candidate.get("candidate_id") and existing.get("title") == clean_title:
            return existing  # prevent duplicate button clicks from creating duplicates

    record = {
        "hypothesis_id": str(uuid.uuid4()),
        "candidate_id": str(candidate["candidate_id"]),
        "title": clean_title,
        "notes": str(notes).strip(),
        "author": str(author),
        "status": "candidate",
        "candidate": dict(candidate),
        "created_at": _now(),
        "updated_at": _now(),
        "checks": [],
    }
    records.append(record)
    _write_atomically(store, records)
    return record


def update_hypothesis(path: str | Path, hypothesis_id: str, **changes: Any) -> dict[str, Any]:
    """Update safe editable fields; candidate evidence is retained separately."""
    allowed = {"title", "notes", "status"}
    unknown = set(changes) - allowed
    if unknown:
        raise ValueError(f"Unsupported hypothesis fields: {', '.join(sorted(unknown))}")
    if "title" in changes and not str(changes["title"]).strip():
        raise ValueError("Hypothesis title must not be empty.")
    records = list_hypotheses(path)
    for record in records:
        if record.get("hypothesis_id") == hypothesis_id:
            for key, value in changes.items():
                record[key] = str(value).strip()
            record["updated_at"] = _now()
            _write_atomically(Path(path), records)
            return record
    raise KeyError(f"Hypothesis not found: {hypothesis_id}")


def append_check(path: str | Path, hypothesis_id: str, result: Mapping[str, Any]) -> dict[str, Any]:
    """Append a verification result to a saved hypothesis and refresh its status."""
    records = list_hypotheses(path)
    for record in records:
        if record.get("hypothesis_id") == hypothesis_id:
            checks = record.setdefault("checks", [])
            checks.append({"checked_at": _now(), "result": dict(result)})
            record["status"] = str(result.get("status", record.get("status", "candidate")))
            record["updated_at"] = _now()
            _write_atomically(Path(path), records)
            return record
    raise KeyError(f"Hypothesis not found: {hypothesis_id}")


def delete_hypothesis(path: str | Path, hypothesis_id: str) -> bool:
    """Delete a saved record. Return False if it did not exist."""
    records = list_hypotheses(path)
    remaining = [r for r in records if r.get("hypothesis_id") != hypothesis_id]
    if len(remaining) == len(records):
        return False
    _write_atomically(Path(path), remaining)
    return True
