"""MADRIGAL network data starter package."""
__version__ = "0.1.0"
