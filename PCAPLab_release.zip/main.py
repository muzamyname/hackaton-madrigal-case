import shutil
import tempfile
from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from scapy.layers.inet import IP, TCP
from scapy.utils import PcapReader

from madrigal_net.cli import build_report
from madrigal_research import analyze_capture_report, load_action_journal
from checksum_analysis import analyze_pcap_checksums
from validation_integration import validate_protocol_analysis

app = FastAPI(
    title="PCAP/PCAPNG Protocol Laboratory",
    description=(
        "Integration API for connecting network analysis, "
        "protocol research and validation modules."
    ),
    version="0.1.0",
)

# Статус отражает текущую стадию интеграции, а не качество анализа данных.
MODULES = {
    "network_analysis": {
        "owner": "participant_1",
        "status": "connected",
    },
    "protocol_research": {
        "owner": "participant_2",
        "status": "ready_for_test",
    },
    "validation": {
        "owner": "participant_3",
        "status": "ready_for_test",
    },
}

# Временное хранилище: результаты пропадут после перезапуска сервера.
CAPTURES = {}


@app.get("/", tags=["System"])
def root():
    return {
        "message": "Protocol Laboratory Integration API",
        "version": app.version,
        "docs": "/docs",
    }


@app.get("/ui", tags=["Interface"], include_in_schema=False)
def ui():
    frontend_path = Path(__file__).resolve().parent / "static" / "index.html"
    if not frontend_path.is_file():
        raise HTTPException(status_code=404, detail="Файл веб-интерфейса static/index.html не найден.")
    return FileResponse(frontend_path)


@app.get("/api/v1/health", tags=["System"])
def health():
    return {
        "status": "ok",
        "service": "integration-api",
        "version": app.version,
    }


@app.get("/api/v1/integration/status", tags=["Integration"])
def integration_status():
    return {
        "status": "in_progress",
        "modules": MODULES,
    }


def attach_packet_metadata(report: dict, capture_path: Path) -> None:
    """Добавить к отчёту № 1 временные метки пакетов, используемых в data-диапазонах.

    Модуль № 2 не читает PCAP и не собирает TCP-потоки самостоятельно. Он использует
    номера исходных кадров из provenance отчёта № 1, чтобы получить timestamp и
    направление соответствующих пакетов для сопоставления с action_journal.csv.
    """
    sessions = report.get("sessions") or []
    wanted_by_frame: dict[int, list[int]] = {}
    endpoint_pairs = []

    for session_index, session in enumerate(sessions):
        endpoint_a = session.get("endpoint_a") or {}
        endpoint_b = session.get("endpoint_b") or {}
        try:
            a = (str(endpoint_a["ip"]), int(endpoint_a["port"]))
            b = (str(endpoint_b["ip"]), int(endpoint_b["port"]))
        except (KeyError, TypeError, ValueError):
            endpoint_pairs.append(None)
            session["packets"] = []
            continue

        endpoint_pairs.append((a, b))
        session["packets"] = []
        frame_numbers = set()
        for direction_info in session.get("directions", []) or []:
            stream = direction_info.get("stream") or {}
            for item in stream.get("ranges", []) or []:
                # Гипотезы строятся только на известных data-диапазонах.
                if item.get("kind") != "data":
                    continue
                for source in item.get("provenance", []) or []:
                    try:
                        frame_numbers.add(int(source["frame_no"]))
                    except (KeyError, TypeError, ValueError):
                        continue

        for frame_no in frame_numbers:
            wanted_by_frame.setdefault(frame_no, []).append(session_index)

    if not wanted_by_frame:
        return

    reader = PcapReader(str(capture_path))
    try:
        # Номера кадров считаются с 1, так же как frame_no в отчёте участника № 1.
        for frame_no, packet in enumerate(reader, start=1):
            interested_sessions = wanted_by_frame.get(frame_no)
            if not interested_sessions or IP not in packet or TCP not in packet:
                continue

            ip = packet[IP]
            tcp = packet[TCP]
            src = (str(ip.src), int(tcp.sport))
            dst = (str(ip.dst), int(tcp.dport))
            try:
                timestamp = float(packet.time) if getattr(packet, "time", None) is not None else None
            except (TypeError, ValueError, OverflowError):
                timestamp = None

            for session_index in interested_sessions:
                pair = endpoint_pairs[session_index]
                if pair is None:
                    continue
                a, b = pair
                if (src == a and dst == b) or (src == b and dst == a):
                    sessions[session_index]["packets"].append({
                        "frame_no": frame_no,
                        "timestamp": timestamp,
                        "src_ip": src[0],
                        "src_port": src[1],
                        "dst_ip": dst[0],
                        "dst_port": dst[1],
                    })
                    break
    finally:
        reader.close()


@app.post("/api/v1/captures", tags=["Captures"])
def upload_capture(file: UploadFile = File(...)):
    filename = Path(file.filename or "capture.pcap").name
    suffix = Path(filename).suffix.lower()

    if suffix not in {".pcap", ".pcapng"}:
        raise HTTPException(
            status_code=400,
            detail="Поддерживаются только файлы PCAP и PCAPNG.",
        )

    try:
        # Временный файл нужен модулю № 1; метаданные пакетов добавляем до его удаления.
        with tempfile.TemporaryDirectory(prefix="pcap_upload_") as temp_dir:
            capture_path = Path(temp_dir) / f"capture{suffix}"
            with capture_path.open("wb") as destination:
                shutil.copyfileobj(file.file, destination)

            report = build_report(capture_path)
            report.setdefault("capture", {})["source_name"] = filename
            attach_packet_metadata(report, capture_path)

            # Проверяем IPv4/TCP checksum на тех же исходных байтах, пока временный
            # PCAP ещё существует. Отказ checksum-проверки не блокирует основной анализ.
            try:
                checksum_analysis = analyze_pcap_checksums(
                    capture_path, capture_name=filename
                )
            except Exception as checksum_exc:
                checksum_analysis = {
                    "schema_version": "0.1",
                    "analysis_type": "ip_tcp_checksum_validation",
                    "status": "error",
                    "capture": {"filename": filename},
                    "summary": {
                        "frames_total": 0,
                        "ipv4_packets": 0,
                        "ipv4_checksum": {"valid": 0, "invalid": 0, "not_assessed": 0},
                        "tcp_ipv4_packets": 0,
                        "tcp_checksum": {"valid": 0, "invalid": 0, "not_assessed": 0},
                        "packets_with_invalid_checksum": 0,
                        "diagnostics_total": 1,
                        "diagnostics_returned": 1,
                        "diagnostics_omitted": 0,
                    },
                    "diagnostics": [{
                        "code": "checksum_analysis_failed",
                        "message": f"Проверка контрольных сумм не выполнена: {type(checksum_exc).__name__}: {checksum_exc}",
                    }],
                    "notes": ["Ошибка checksum-проверки не отменяет успешно сформированный основной отчёт."],
                }

        stats = report.get("stats", {})
        capture_id = uuid4().hex
        record = {
            "capture_id": capture_id,
            "filename": filename,
            "format": suffix[1:].upper(),
            "status": "ready",
            "checksum_analysis": checksum_analysis,
            "summary": {
                "frames_total": stats.get("frames_total"),
                "tcp_ipv4_packets": stats.get("tcp_ipv4_packets"),
                "tcp_payload_bytes": stats.get("tcp_payload_bytes"),
                "sessions_count": report.get("sessions_count"),
            },
            "report": report,
        }
        CAPTURES[capture_id] = record
        return record

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Не удалось обработать файл: {exc}",
        ) from exc
    finally:
        file.file.close()


@app.get("/api/v1/captures/{capture_id}", tags=["Captures"])
def get_capture(capture_id: str):
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Загрузите файл ещё раз.",
        )
    return record


@app.get("/api/v1/captures/{capture_id}/summary", tags=["Captures"])
def get_capture_summary(capture_id: str):
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Загрузите файл ещё раз.",
        )
    return {
        "capture_id": capture_id,
        "filename": record["filename"],
        "format": record["format"],
        "summary": record["summary"],
    }


@app.get("/api/v1/captures/{capture_id}/checksums", tags=["Checksum analysis"])
def get_capture_checksums(capture_id: str):
    """Return IPv4/TCP checksum inspection calculated during upload."""
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Сначала загрузите PCAP/PCAPNG.",
        )
    analysis = record.get("checksum_analysis")
    if analysis is None:
        raise HTTPException(
            status_code=404,
            detail="Отчёт проверки контрольных сумм для этого захвата отсутствует.",
        )
    return {
        "capture_id": capture_id,
        "filename": record["filename"],
        "checksum_analysis": analysis,
    }


@app.post(
    "/api/v1/captures/{capture_id}/protocol-analysis",
    tags=["Protocol analysis"],
)
def run_protocol_analysis(capture_id: str, journal_file: UploadFile = File(...)):
    """Запустить модуль № 2 для уже загруженного PCAP и CSV-журнала действий."""
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Сначала загрузите PCAP/PCAPNG.",
        )

    try:
        journal_name = Path(journal_file.filename or "").name
        if Path(journal_name).suffix.lower() != ".csv":
            raise HTTPException(
                status_code=400,
                detail="Загрузите CSV-журнал действий (.csv).",
            )

        with tempfile.TemporaryDirectory(prefix="action_journal_") as temp_dir:
            journal_path = Path(temp_dir) / "action_journal.csv"
            with journal_path.open("wb") as destination:
                shutil.copyfileobj(journal_file.file, destination)
            journal_rows = load_action_journal(journal_path)

        result = analyze_capture_report(record["report"], journal_rows)
        record["protocol_analysis"] = result
        # If protocol analysis is rerun, an older validation report is no longer current.
        record.pop("validation", None)
        MODULES["protocol_research"]["status"] = "connected"
        return {
            "capture_id": capture_id,
            "filename": record["filename"],
            "protocol_analysis": result,
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Не удалось выполнить анализ протокола: {exc}",
        ) from exc
    finally:
        journal_file.file.close()


@app.post("/api/v1/captures/{capture_id}/validation", tags=["Validation"])
def run_capture_validation(capture_id: str):
    """Validate module #2's candidate evidence using module #3's FieldRule engine."""
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Сначала загрузите PCAP/PCAPNG.",
        )

    protocol_analysis = record.get("protocol_analysis")
    if not protocol_analysis:
        raise HTTPException(
            status_code=409,
            detail=(
                "Сначала выполните POST /api/v1/captures/{capture_id}/protocol-analysis "
                "и загрузите соответствующий action_journal.csv."
            ),
        )

    capture_metadata = (record.get("report") or {}).get("capture") or {}
    source_sha256 = str(capture_metadata.get("source_sha256") or "")
    try:
        validation = validate_protocol_analysis(
            protocol_analysis,
            source_id=record["filename"],
            source_sha256=source_sha256,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    record["validation"] = validation
    MODULES["validation"]["status"] = "connected"
    return {
        "capture_id": capture_id,
        "filename": record["filename"],
        "validation": validation,
    }


@app.get("/api/v1/captures/{capture_id}/validation", tags=["Validation"])
def get_capture_validation(capture_id: str):
    """Return the most recent validation result for a capture."""
    record = CAPTURES.get(capture_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail="Захват не найден. Загрузите файл ещё раз.",
        )
    validation = record.get("validation")
    if validation is None:
        raise HTTPException(
            status_code=404,
            detail="Отчёт валидации ещё не создан. Выполните POST /api/v1/captures/{capture_id}/validation.",
        )
    return {
        "capture_id": capture_id,
        "filename": record["filename"],
        "validation": validation,
    }
