from pathlib import Path

from scapy.all import IP, rdpcap, wrpcap

source = Path(r"sample_protocol\research\01_configuration.pcap")
output = Path(r"artifacts\01_configuration_bad_ip_checksum.pcap")

if not source.exists():
    raise SystemExit(
        f"Исходный PCAP не найден: {source.resolve()}"
    )

packets = rdpcap(str(source))
output.parent.mkdir(parents=True, exist_ok=True)

for frame_no, packet in enumerate(packets, start=1):
    if IP in packet:
        old_checksum = packet[IP].chksum

        # Меняем контрольную сумму только у одного IP-пакета.
        packet[IP].chksum = (int(old_checksum) ^ 0xFFFF) & 0xFFFF

        wrpcap(str(output), packets)

        print(f"Тестовый файл создан: {output.resolve()}")
        print(f"Изменён кадр: {frame_no}")
        print(f"Старая checksum: 0x{old_checksum:04x}")
        print(f"Новая checksum:  0x{packet[IP].chksum:04x}")
        break
else:
    raise SystemExit("В исходном файле не найдено ни одного IPv4-пакета.")