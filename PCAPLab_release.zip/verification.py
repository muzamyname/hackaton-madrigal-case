"""Проверка правил разбора сетевых сообщений (участник №3).

Сам PCAP мы не читаем. От участника №1 приходят уже готовые сообщения,
от участника №2 - правила. Здесь мы только применяем правила к сообщениям,
записываем результат и доказательства (байты, хеши, номера пакетов).

Важно: PASS говорит лишь о том, что правило сработало на конкретном
сообщении. Для всего протокола это ничего не доказывает.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Literal

Status = Literal["PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE"]

STATUSES = ("PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE")

# Человекочитаемые подписи. Ключ - (статус, причина).
# Причину ставит check_one, так что разбирать текст объяснения не нужно.
LABELS = {
    ("PASS", ""): "Условие выполнено",
    ("FAIL", ""): "Найдено несоответствие правилу",
    ("NOT_APPLICABLE", "disabled"): "Правило отключено",
    ("NOT_APPLICABLE", "other_direction"): "Правило не применяется",
    ("UNKNOWN", "ambiguous"): "Нельзя сделать однозначный вывод",
    ("UNKNOWN", "incomplete"): "Сообщение неполное - проверка невозможна",
    ("UNKNOWN", "too_short"): "Не хватает байтов для проверки",
}

HEX_RE = re.compile(r"[0-9A-F]*")


def sha256_hex(data: bytes) -> str:
    return sha256(data).hexdigest()


def normalize_hex(text: str) -> str:
    """'0x1f 8B' -> '1F8B'. Пробелы и префикс 0x в правилах разрешены."""
    cleaned = text.strip().replace(" ", "")
    if cleaned[:2].lower() == "0x":
        cleaned = cleaned[2:]
    return cleaned.upper()


@dataclass(frozen=True)
class MessageSample:
    """Одно сообщение, которое собрал участник №1.

    source_id       - id записи (например, относительный путь к pcap)
    source_sha256   - хеш исходного pcap/pcapng
    message_id      - id сообщения внутри записи
    payload         - байты прикладного уровня
    complete        - False, если сообщение в захвате обрывается
    ambiguous       - True, если собрать сообщение можно было по-разному
    """

    source_id: str
    source_sha256: str
    message_id: str
    payload: bytes
    direction: str = "unknown"
    packet_numbers: tuple[int, ...] = ()
    complete: bool = True
    ambiguous: bool = False
    notes: str = ""

    @property
    def payload_sha256(self) -> str:
        return sha256_hex(self.payload)


@dataclass(frozen=True)
class FieldRule:
    """Простое правило про одно сообщение.

    kind:
      uint   - читаем число из байтов [offset : offset + size]
      hex    - сравниваем те же байты как HEX-строку
      length - проверяем длину всего сообщения (offset и size не нужны)

    Условие задаётся через equals либо через min_value / max_value.
    Для hex можно использовать только equals (строка).
    """

    rule_id: str
    description: str
    kind: Literal["uint", "hex", "length"]
    offset: int = 0
    size: int = 1
    byte_order: Literal["big", "little"] = "big"
    equals: int | str | None = None
    min_value: int | None = None
    max_value: int | None = None
    enabled: bool = True
    scope_direction: str | None = None

    def __post_init__(self) -> None:
        if not self.rule_id.strip():
            raise ValueError("У правила должен быть непустой rule_id")
        if self.kind not in ("uint", "hex", "length"):
            raise ValueError(f"{self.rule_id}: неизвестный тип правила {self.kind!r}")
        if self.byte_order not in ("big", "little"):
            raise ValueError(f"{self.rule_id}: byte_order должен быть 'big' или 'little'")
        if self.kind != "length" and (self.offset < 0 or self.size < 1):
            raise ValueError(f"{self.rule_id}: offset >= 0 и size >= 1")
        if self.min_value is not None and self.max_value is not None \
                and self.min_value > self.max_value:
            raise ValueError(f"{self.rule_id}: min_value больше max_value")

        if self.equals is None and self.min_value is None and self.max_value is None:
            # Иначе правило всегда давало бы PASS (или всегда FAIL) ни о чём.
            raise ValueError(f"{self.rule_id}: не задано ни одно условие")

        if self.kind == "hex":
            self._check_hex_rule()
        else:
            self._check_numeric_rule()

    def _check_hex_rule(self) -> None:
        if not isinstance(self.equals, str):
            raise ValueError(f"{self.rule_id}: для hex нужен equals в виде строки")
        if self.min_value is not None or self.max_value is not None:
            raise ValueError(f"{self.rule_id}: для hex границы min/max не имеют смысла")
        wanted = normalize_hex(self.equals)
        if not HEX_RE.fullmatch(wanted):
            raise ValueError(f"{self.rule_id}: в equals есть не-HEX символы")
        if len(wanted) != self.size * 2:
            raise ValueError(
                f"{self.rule_id}: size={self.size}, значит нужно {self.size * 2} "
                f"HEX-символов, а получено {len(wanted)}"
            )
        # Запоминаем уже нормализованное значение (класс frozen, поэтому так).
        object.__setattr__(self, "equals", wanted)

    def _check_numeric_rule(self) -> None:
        if self.equals is not None:
            if isinstance(self.equals, bool) or not isinstance(self.equals, int):
                raise ValueError(f"{self.rule_id}: для {self.kind} equals должен быть числом")
            if self.kind == "uint" and not 0 <= self.equals < 256 ** self.size:
                raise ValueError(f"{self.rule_id}: equals не помещается в {self.size} байт(а)")


@dataclass
class CheckResult:
    """Результат одного правила на одном сообщении."""

    rule_id: str
    status: Status
    source_id: str
    source_sha256: str
    message_id: str
    direction: str
    packet_numbers: list[int]
    payload_sha256: str
    offset: int | None
    size: int | None
    observed: Any = None
    expected: Any = None
    evidence_hex: str = ""
    explanation: str = ""
    reason: str = ""  # машинная причина для UNKNOWN / NOT_APPLICABLE

    @property
    def status_label(self) -> str:
        default = "Недостаточно данных для надёжного вывода"
        return LABELS.get((self.status, self.reason), default)


@dataclass
class VerificationReport:
    rule_set_sha256: str
    results: list[CheckResult] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def summary(self) -> dict[str, int]:
        counts = {name: 0 for name in STATUSES}
        for item in self.results:
            counts[item.status] += 1
        counts["TOTAL"] = len(self.results)
        return counts

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 2,
            "rule_set_sha256": self.rule_set_sha256,
            "metadata": self.metadata,
            "summary": self.summary(),
            "results": [{**asdict(r), "status_label": r.status_label} for r in self.results],
        }

    def save_json(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
        # Пишем во временный файл и подменяем, чтобы при сбое не остался
        # наполовину записанный отчёт.
        tmp = target.with_name(target.name + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, target)


def load_report(path: str | Path) -> dict[str, Any]:
    """Читает сохранённый отчёт, чтобы потом передать его в report_is_current."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def rules_fingerprint(rules: Iterable[FieldRule]) -> str:
    """Хеш настроек правил. Порядок правил на результат не влияет."""
    items = [asdict(r) for r in sorted(rules, key=lambda r: r.rule_id)]
    raw = json.dumps(items, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return sha256_hex(raw.encode("utf-8"))


def describe_condition(rule: FieldRule) -> str:
    parts = []
    if rule.equals is not None:
        parts.append(f"равно {rule.equals!r}")
    if rule.min_value is not None:
        parts.append(f">= {rule.min_value}")
    if rule.max_value is not None:
        parts.append(f"<= {rule.max_value}")
    return ", ".join(parts)


def _condition_holds(value: Any, rule: FieldRule) -> bool:
    if rule.equals is not None and value != rule.equals:
        return False
    if rule.min_value is not None and value < rule.min_value:
        return False
    if rule.max_value is not None and value > rule.max_value:
        return False
    return True


def check_one(sample: MessageSample, rule: FieldRule) -> CheckResult:
    """Применяет одно правило к одному сообщению."""

    def make(status: Status, *, reason: str = "", observed: Any = None,
             evidence: str = "", text: str = "") -> CheckResult:
        is_length = rule.kind == "length"
        return CheckResult(
            rule_id=rule.rule_id,
            status=status,
            source_id=sample.source_id,
            source_sha256=sample.source_sha256,
            message_id=sample.message_id,
            direction=sample.direction,
            packet_numbers=list(sample.packet_numbers),
            payload_sha256=sample.payload_sha256,
            offset=None if is_length else rule.offset,
            size=None if is_length else rule.size,
            observed=observed,
            expected=describe_condition(rule),
            evidence_hex=evidence,
            explanation=text,
            reason=reason,
        )

    if not rule.enabled:
        return make("NOT_APPLICABLE", reason="disabled", text="Правило отключено.")

    if rule.scope_direction and sample.direction != rule.scope_direction:
        return make("NOT_APPLICABLE", reason="other_direction", observed=sample.direction,
                    text=f"Правило только для направления {rule.scope_direction!r}, "
                         f"а у сообщения {sample.direction!r}.")

    if sample.ambiguous:
        return make("UNKNOWN", reason="ambiguous",
                    text="Сообщение восстановлено неоднозначно, вывод не делаем.")
    if not sample.complete:
        return make("UNKNOWN", reason="incomplete",
                    text="Сообщение неполное, правило нельзя надёжно проверить.")

    evidence = ""
    if rule.kind == "length":
        observed: Any = len(sample.payload)
    else:
        end = rule.offset + rule.size
        if end > len(sample.payload):
            return make("UNKNOWN", reason="too_short",
                        text=f"Нужны байты [{rule.offset}:{end}], а длина сообщения "
                             f"всего {len(sample.payload)} байт.")
        chunk = sample.payload[rule.offset:end]
        evidence = chunk.hex(" ").upper()
        if rule.kind == "uint":
            observed = int.from_bytes(chunk, byteorder=rule.byte_order, signed=False)
        else:
            observed = chunk.hex().upper()

    if _condition_holds(observed, rule):
        return make("PASS", observed=observed, evidence=evidence, text="Условие выполнено.")
    return make("FAIL", observed=observed, evidence=evidence,
                text=f"Получено {observed!r}, ожидалось: {describe_condition(rule)}.")


def verify_corpus(samples: Iterable[MessageSample], rules: Iterable[FieldRule],
                  metadata: dict[str, Any] | None = None) -> VerificationReport:
    """Прогоняет каждое правило по каждому сообщению.

    Это проверка отдельных сообщений. Связывать запрос с ответом и собирать
    TCP-потоки мы не умеем и не должны.
    """
    sample_list = list(samples)
    rule_list = list(rules)

    ids = [r.rule_id for r in rule_list]
    duplicates = sorted({i for i in ids if ids.count(i) > 1})
    if duplicates:
        raise ValueError(f"Повторяющиеся rule_id: {', '.join(duplicates)}")

    # Запоминаем, по каким версиям файлов считали, чтобы потом узнать,
    # не устарел ли отчёт.
    sources: dict[str, str] = {}
    for s in sample_list:
        known = sources.setdefault(s.source_id, s.source_sha256)
        if known != s.source_sha256:
            raise ValueError(f"У источника {s.source_id} два разных хеша")

    report = VerificationReport(
        rule_set_sha256=rules_fingerprint(rule_list),
        metadata={
            "sample_count": len(sample_list),
            "rule_count": len(rule_list),
            "source_ids": sorted(sources),
            "sources": sources,
            **(metadata or {}),
        },
    )
    for s in sample_list:
        for r in rule_list:
            report.results.append(check_one(s, r))
    return report


def report_is_current(report_data: dict[str, Any], rules: Iterable[FieldRule],
                      source_hashes: dict[str, str]) -> bool:
    """True, если правила не менялись и все исходные файлы те же.

    source_hashes - текущие SHA-256 capture-файлов по source_id. Если
    какого-то источника из отчёта в нём нет или хеш другой, отчёт устарел.
    """
    if report_data.get("rule_set_sha256") != rules_fingerprint(rules):
        return False

    # Берём источники из metadata, а если их там нет (старый формат) -
    # собираем из самих результатов.
    recorded = dict(report_data.get("metadata", {}).get("sources", {}))
    for item in report_data.get("results", []):
        recorded.setdefault(item.get("source_id"), item.get("source_sha256"))

    return all(source_hashes.get(sid) == digest for sid, digest in recorded.items())


if __name__ == "__main__":
    # Маленький пример, чтобы быстро проверить, что всё работает.
    demo = MessageSample("demo.pcap", sha256_hex(b"demo"), "msg-1",
                         bytes.fromhex("A1 B2 00 05 FF"), direction="client",
                         packet_numbers=(3, 4))
    demo_rules = [
        FieldRule("magic", "Сигнатура в начале", "hex", offset=0, size=2, equals="A1 B2"),
        FieldRule("len_field", "Поле длины", "uint", offset=2, size=2, equals=5),
        FieldRule("total_len", "Общая длина", "length", min_value=4, max_value=64),
    ]
    out = verify_corpus([demo], demo_rules)
    print(json.dumps(out.summary(), ensure_ascii=False))
