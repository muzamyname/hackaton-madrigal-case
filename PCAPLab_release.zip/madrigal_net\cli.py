from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any

from .reader import read_capture
from .sessions import group_sessions
from .reassemble import reassemble_direction


def _json_safe_packet(p: dict[str, Any], include_payload: bool) -> dict[str, Any]:
    result = {k: v for k, v in p.items() if k != "payload"}
    if include_payload:
        result["payload_hex"] = p["payload"].hex()
    return result


def build_report(path: str, include_packet_payload: bool = False) -> dict[str, Any]:
    capture = read_capture(path)
    sessions = group_sessions(capture["packets"])
    result_sessions = []
    for s in sessions:
        directions = []
        for direction in (0, 1):
            subset = [p for p in s["packets"] if p["direction"] == direction]
            stream = reassemble_direction(subset)
            directions.append({"direction": direction, "stream": stream})
        result_sessions.append({
            "session_id": s["session_id"],
            "capture_id": s["capture_id"],
            "endpoint_a": s["endpoint_a"],
            "endpoint_b": s["endpoint_b"],
            "start_observed": s["start_observed"],
            "initiator": s["initiator"],
            "closed_observed": s["closed_observed"],
            "packet_count": s["packet_count"],
            "payload_bytes": s["payload_bytes"],
            "diagnostics": s["diagnostics"],
            "directions": directions,
            "packets": [_json_safe_packet(p, include_packet_payload) for p in s["packets"]],
        })
    return {
        "schema_version": "0.1",
        "capture": capture["capture"],
        "stats": capture["stats"],
        "sessions_count": len(result_sessions),
        "sessions": result_sessions,
        "notes": [
            "MVP for Ethernet/IPv4/TCP only.",
            "The report is evidence about the supplied capture, not a claim that the capture contains the full connection.",
            "A checksum status of not_assessed is not the same as a valid checksum.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="MADRIGAL participant #1: inspect PCAP/PCAPNG")
    parser.add_argument("capture", help="Path to a PCAP or PCAPNG file")
    parser.add_argument("--out", default="artifacts/report.json", help="Output JSON report path")
    parser.add_argument("--include-packet-payload", action="store_true", help="Include packet payload hex in JSON (makes report larger)")
    args = parser.parse_args()
    try:
        report = build_report(args.capture, args.include_packet_payload)
    except (OSError, ValueError) as exc:
        raise SystemExit(f"ERROR: {exc}") from exc
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Capture: {report['capture']['source_name']}")
    print(f"Frames: {report['stats']['frames_total']}")
    print(f"IPv4: {report['stats']['ipv4_packets']}")
    print(f"TCP/IPv4: {report['stats']['tcp_ipv4_packets']}")
    print(f"TCP payload bytes (sum across captured packets): {report['stats']['tcp_payload_bytes']}")
    print(f"Session candidates: {report['sessions_count']}")
    print(f"Report written: {out.resolve()}")

if __name__ == "__main__":
    main()
