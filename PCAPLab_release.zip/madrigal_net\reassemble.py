"""Small interval-based TCP payload reconstruction with provenance.

Known byte ranges, gaps, and conflicting overlaps are distinct result items.
No gap is padded with zero bytes. This is an MVP and assumes the observed
sequence span per direction is less than 2**31 bytes (suitable for the stated
100 MiB benchmark profile).
"""
from __future__ import annotations
from typing import Any

MOD = 2 ** 32
HALF = 2 ** 31


def _unwrap(seq: int, reference: int) -> int:
    """Map a uint32 sequence number to the nearest signed offset from reference."""
    return ((seq - reference + HALF) % MOD) - HALF


def reassemble_direction(packets: list[dict[str, Any]]) -> dict[str, Any]:
    """Reassemble one direction. `packets` must all have the same direction.

    Returns ranges sorted by stream offset. Internal gaps between observed data
    are marked unknown. We do not invent a missing prefix/suffix outside the
    observed payload range.
    """
    data_packets = [p for p in packets if p.get("payload")]
    if not data_packets:
        return {"status": "no_payload", "direction": packets[0]["direction"] if packets else None, "ranges": [], "diagnostics": []}

    ref = int(data_packets[0]["payload_seq_raw"])
    segs = []
    for p in data_packets:
        start_signed = _unwrap(int(p["payload_seq_raw"]), ref)
        segs.append({"start_signed": start_signed, "end_signed": start_signed + len(p["payload"]), "payload": p["payload"], "packet": p})
    absolute_min = min(s["start_signed"] for s in segs)
    for s in segs:
        s["start"] = s["start_signed"] - absolute_min
        s["end"] = s["end_signed"] - absolute_min

    boundaries = sorted({x for s in segs for x in (s["start"], s["end"])})
    ranges: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []
    for left, right in zip(boundaries, boundaries[1:]):
        if right <= left:
            continue
        covering = [s for s in segs if s["start"] <= left and s["end"] >= right]
        if not covering:
            ranges.append({"kind": "gap", "offset_start": left, "offset_end": right, "length": right-left, "value": None, "provenance": []})
            diagnostics.append({"code": "missing_bytes", "severity": "warning", "offset_start": left, "offset_end": right, "message": "No captured payload covers this sequence range."})
            continue

        versions: dict[bytes, list[dict[str, Any]]] = {}
        for s in covering:
            lo = left - s["start"]
            hi = right - s["start"]
            chunk = s["payload"][lo:hi]
            p = s["packet"]
            provenance = {
                "capture_id": p["capture_id"],
                "frame_no": p["frame_no"],
                "payload_start": lo,
                "payload_end": hi,
                "seq_start_raw": (int(p["payload_seq_raw"]) + lo) % MOD,
                "seq_end_raw_exclusive": (int(p["payload_seq_raw"]) + hi) % MOD,
            }
            versions.setdefault(chunk, []).append(provenance)

        if len(versions) == 1:
            value, provenance = next(iter(versions.items()))
            ranges.append({"kind": "data", "offset_start": left, "offset_end": right, "length": right-left, "value_hex": value.hex(), "provenance": provenance})
        else:
            alternatives = []
            for value, provenance in versions.items():
                alternatives.append({"value_hex": value.hex(), "provenance": provenance})
            ranges.append({"kind": "conflict", "offset_start": left, "offset_end": right, "length": right-left, "alternatives": alternatives, "provenance": [p for v in versions.values() for p in v]})
            diagnostics.append({"code": "conflicting_overlap", "severity": "error", "offset_start": left, "offset_end": right, "message": "Multiple captured segments contain different bytes for the same sequence range."})

    # Coalesce adjacent gaps to avoid one diagnostic per packet-boundary interval.
    merged: list[dict[str, Any]] = []
    for r in ranges:
        if merged and r["kind"] == "gap" and merged[-1]["kind"] == "gap" and merged[-1]["offset_end"] == r["offset_start"]:
            merged[-1]["offset_end"] = r["offset_end"]
            merged[-1]["length"] += r["length"]
        else:
            merged.append(r)

    return {
        "status": "ok",
        "direction": data_packets[0]["direction"],
        "reference_seq_raw": ref,
        "observed_payload_bytes": sum(len(p["payload"]) for p in data_packets),
        "ranges": merged,
        "diagnostics": diagnostics,
        "limitations": [
            "No missing prefix or suffix is inferred outside observed payload intervals.",
            "Sequence unwrapping assumes the observed span in one direction is less than 2**31 bytes.",
            "Session grouping is heuristic; inspect diagnostics for possible tuple reuse.",
        ],
    }
