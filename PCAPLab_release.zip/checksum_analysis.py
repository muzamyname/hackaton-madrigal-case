"""IPv4 and TCP checksum inspection for PCAP/PCAPNG captures.

Checks describe the bytes present in the capture. A checksum reported as invalid
can be an apparent offload artifact when a capture was made on the sending host.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any


_STATUSES = ("valid", "invalid", "not_assessed")


def internet_checksum(data: bytes) -> int:
    """Return the 16-bit one's-complement checksum (RFC 1071)."""
    if len(data) % 2:
        data += b"\x00"
    total = 0
    for offset in range(0, len(data), 2):
        total += (data[offset] << 8) | data[offset + 1]
        total = (total & 0xFFFF) + (total >> 16)
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def _not_assessed(reason: str, stored: int | None = None) -> dict[str, Any]:
    return {
        "status": "not_assessed",
        "stored_hex": f"0x{stored:04x}" if stored is not None else None,
        "computed_hex": None,
        "reason": reason,
    }


def check_ipv4_header_checksum(header: bytes) -> dict[str, Any]:
    """Check a captured IPv4 header (not the whole datagram)."""
    if len(header) < 20:
        return _not_assessed("ipv4_header_truncated")

    version = header[0] >> 4
    header_length = (header[0] & 0x0F) * 4
    if version != 4:
        return _not_assessed("not_ipv4_header")
    if header_length < 20:
        return _not_assessed("invalid_ipv4_header_length")
    if len(header) < header_length:
        return _not_assessed("ipv4_options_truncated")

    header = header[:header_length]
    stored = int.from_bytes(header[10:12], "big")
    zeroed = bytearray(header)
    zeroed[10:12] = b"\x00\x00"
    computed = internet_checksum(bytes(zeroed))
    return {
        "status": "valid" if computed == stored else "invalid",
        "stored_hex": f"0x{stored:04x}",
        "computed_hex": f"0x{computed:04x}",
        "reason": None if computed == stored else "ipv4_checksum_mismatch_in_capture",
    }


def check_tcp_segment_checksum(
    source_ip: bytes, destination_ip: bytes, tcp_segment: bytes
) -> dict[str, Any]:
    """Check a complete TCP segment using the IPv4 pseudo-header."""
    if len(source_ip) != 4 or len(destination_ip) != 4:
        return _not_assessed("invalid_ipv4_pseudo_header_address")
    if len(tcp_segment) < 20:
        return _not_assessed("tcp_header_truncated")
    if len(tcp_segment) > 0xFFFF:
        return _not_assessed("tcp_segment_length_out_of_range")

    stored = int.from_bytes(tcp_segment[16:18], "big")
    zeroed = bytearray(tcp_segment)
    zeroed[16:18] = b"\x00\x00"
    pseudo_header = (
        source_ip
        + destination_ip
        + b"\x00\x06"
        + len(tcp_segment).to_bytes(2, "big")
    )
    computed = internet_checksum(pseudo_header + bytes(zeroed))
    return {
        "status": "valid" if computed == stored else "invalid",
        "stored_hex": f"0x{stored:04x}",
        "computed_hex": f"0x{computed:04x}",
        "reason": None if computed == stored else "tcp_checksum_mismatch_in_capture",
    }


def _status_bucket(counter: Counter[str]) -> dict[str, int]:
    return {status: int(counter.get(status, 0)) for status in _STATUSES}


def analyze_pcap_checksums(
    capture_path: str | Path,
    capture_name: str | None = None,
    *,
    max_diagnostics: int = 1000,
) -> dict[str, Any]:
    """Inspect IPv4 header and TCP-over-IPv4 checksums from PCAP/PCAPNG.

    Full TCP checksum verification is not possible for fragmented IPv4 datagrams
    or when the captured segment is truncated, so those entries are not_assessed.
    Only non-valid packet checks are placed into diagnostics to keep responses
    manageable for larger captures.
    """
    try:
        from scapy.layers.inet import IP
        from scapy.utils import PcapReader
    except ImportError as exc:  # make the missing dependency explicit to the caller
        raise RuntimeError("Для проверки контрольных сумм требуется установленный Scapy.") from exc

    path = Path(capture_path)
    ip_counter: Counter[str] = Counter()
    tcp_counter: Counter[str] = Counter()
    packet_diagnostics: list[dict[str, Any]] = []
    frames_total = 0
    ipv4_packets = 0
    tcp_ipv4_packets = 0
    packets_with_invalid_checksum = 0
    diagnostics_total = 0

    reader = PcapReader(str(path))
    try:
        for frame_no, packet in enumerate(reader, start=1):
            frames_total = frame_no
            if IP not in packet:
                continue

            ip_layer = packet[IP]
            raw_ip = bytes(ip_layer)
            if len(raw_ip) < 1 or (raw_ip[0] >> 4) != 4:
                continue
            ipv4_packets += 1

            ip_check = check_ipv4_header_checksum(raw_ip)
            ip_counter[ip_check["status"]] += 1

            header_length = (raw_ip[0] & 0x0F) * 4 if len(raw_ip) >= 1 else 0
            total_length = int.from_bytes(raw_ip[2:4], "big") if len(raw_ip) >= 4 else 0
            protocol_number = raw_ip[9] if len(raw_ip) >= 10 else None
            tcp_check: dict[str, Any] | None = None
            src_ip = str(getattr(ip_layer, "src", "")) or None
            dst_ip = str(getattr(ip_layer, "dst", "")) or None
            src_port: int | None = None
            dst_port: int | None = None

            if protocol_number == 6:
                tcp_ipv4_packets += 1
                fragment_field = int.from_bytes(raw_ip[6:8], "big") if len(raw_ip) >= 8 else 0
                fragment_offset = fragment_field & 0x1FFF
                more_fragments = bool(fragment_field & 0x2000)

                if header_length < 20 or total_length < header_length:
                    tcp_check = _not_assessed("invalid_ipv4_length_fields")
                elif fragment_offset != 0 or more_fragments:
                    tcp_check = _not_assessed("fragmented_ipv4_datagram")
                elif total_length > len(raw_ip):
                    tcp_check = _not_assessed("captured_tcp_segment_truncated")
                else:
                    tcp_segment = raw_ip[header_length:total_length]
                    if len(tcp_segment) >= 4:
                        src_port = int.from_bytes(tcp_segment[0:2], "big")
                        dst_port = int.from_bytes(tcp_segment[2:4], "big")
                    tcp_check = check_tcp_segment_checksum(
                        raw_ip[12:16], raw_ip[16:20], tcp_segment
                    )
                tcp_counter[tcp_check["status"]] += 1

            ip_status = ip_check["status"]
            tcp_status = tcp_check["status"] if tcp_check else None
            has_invalid = ip_status == "invalid" or tcp_status == "invalid"
            has_diagnostic = ip_status != "valid" or (tcp_status is not None and tcp_status != "valid")
            if has_invalid:
                packets_with_invalid_checksum += 1

            if has_diagnostic:
                diagnostics_total += 1
                if len(packet_diagnostics) < max_diagnostics:
                    if src_port is None and header_length >= 20 and len(raw_ip) >= 10 and raw_ip[9] == 6 and len(raw_ip) >= header_length + 4:
                        src_port = int.from_bytes(raw_ip[header_length:header_length + 2], "big")
                        dst_port = int.from_bytes(raw_ip[header_length + 2:header_length + 4], "big")
                    packet_diagnostics.append({
                        "frame_no": frame_no,
                        "src_ip": src_ip,
                        "src_port": src_port,
                        "dst_ip": dst_ip,
                        "dst_port": dst_port,
                        "protocol": "TCP" if protocol_number == 6 else protocol_number,
                        "ip_checksum": ip_check,
                        "tcp_checksum": tcp_check,
                    })
    finally:
        reader.close()

    diagnostics_omitted = max(0, diagnostics_total - len(packet_diagnostics))
    return {
        "schema_version": "0.1",
        "analysis_type": "ip_tcp_checksum_validation",
        "status": "completed",
        "capture": {
            "filename": capture_name or path.name,
        },
        "summary": {
            "frames_total": frames_total,
            "ipv4_packets": ipv4_packets,
            "ipv4_checksum": _status_bucket(ip_counter),
            "tcp_ipv4_packets": tcp_ipv4_packets,
            "tcp_checksum": _status_bucket(tcp_counter),
            "packets_with_invalid_checksum": packets_with_invalid_checksum,
            "diagnostics_total": diagnostics_total,
            "diagnostics_returned": len(packet_diagnostics),
            "diagnostics_omitted": diagnostics_omitted,
        },
        "diagnostics": packet_diagnostics,
        "notes": [
            "IPv4 checksum is checked over the IPv4 header, including options when present.",
            "TCP checksum is checked over the complete unfragmented TCP segment and IPv4 pseudo-header.",
            "Fragmented IPv4 datagrams and truncated TCP segments are marked not_assessed; they are not treated as invalid.",
            "An invalid checksum means the captured bytes do not match the checksum field. On a capture made on the sending host, checksum offload can produce apparent mismatches before the network adapter fills the checksum. Confirm with an external capture before concluding that a packet was transmitted with a bad checksum.",
            "Only IPv4 and TCP over IPv4 are assessed; IPv6, UDP, and other protocols are outside this check.",
        ],
    }
