# MADRIGAL — модуль гипотез (участник № 2)

Модуль работает **поверх отчёта** `madrigal_net.cli.build_report`: он не читает PCAP и не повторяет TCP-реконструкцию.

## Что делает

1. Склеивает соседние известные `data`-диапазоны. `gap` и `conflict` не заполняет.
2. Ищет полные кадры `A6 5C`, где байты 2–3 — длина тела big-endian, заголовок — 8 байт.
3. Сопоставляет сообщения со строками `action_journal.csv` по имени PCAP и времени исходных пакетов.
4. Ищет простые кандидаты полей: числа big-endian шириной 1/2/4 байта, boolean `0/1`, UTF-8 строки с проверкой байта длины перед строкой.
5. Возвращает один обычный Python-словарь — его можно вернуть из FastAPI как JSON.

Все гипотезы предварительные. Совпадение по времени не доказывает причинность, а совпадение байтов не доказывает смысл поля.

## Вызов из backend

```python
from madrigal_net.cli import build_report
from madrigal_research import analyze_capture_report, load_action_journal

report = build_report("sample_protocol/research/01_configuration.pcap")
journal = load_action_journal("sample_protocol/action_journal.csv")
result = analyze_capture_report(report, journal)
```

`analyze_capture_report(report, journal_rows)` — основная функция для API участника № 4. Этот пакет намеренно **не добавляет маршрут FastAPI** и не изменяет `main.py`.

## Основные функции

- `extract_messages(report)` — извлекает полные кадры из восстановленных потоков.
- `associate_actions(messages, journal_rows)` — привязывает сообщения к журналу по времени.
- `generate_hypothesis_candidates(messages)` — генерирует кандидаты полей.
- `verify_candidate(candidate, messages)` — повторно проверяет сохранённую гипотезу.
- `load_action_journal(path)` — читает CSV.
- `save_hypothesis`, `list_hypotheses`, `update_hypothesis`, `append_check`, `delete_hypothesis` — простой JSON-store для GUI.

## Запуск тестов

Из `hackaton/`:

```bash
python -m pytest tests/test_hypothesis_engine.py -q
```

Нужны стандартная библиотека Python и уже существующий пакет `madrigal_net`.
