from madrigal_research.engine import (
    associate_actions,
    extract_messages,
    generate_hypothesis_candidates,
)


def prov(frame):
    return [{"frame_no": frame, "payload_start": 0, "payload_end": 17}]


def make_report():
    # Three known set-config requests, matching the documented configuration
    # experiment. Stream ranges are deliberately split across TCP segment-like
    # chunks to exercise stream coalescing before framing.
    msg1 = bytes.fromhex("A6 5C 00 09 00 02 00 20 01 03 E8 08 34 03 4C 61 62")
    msg2 = bytes.fromhex("A6 5C 00 09 00 04 00 20 01 03 E8 07 6C 03 4C 61 62")
    msg3 = bytes.fromhex("A6 5C 00 09 00 07 00 20 00 03 E8 08 34 03 4C 61 62")
    joined = msg1 + msg2 + msg3
    ranges = []
    frame_specs = []
    offset = 0
    frame_no = 1
    for msg in (msg1, msg2, msg3):
        # split each message into chunks at non-frame boundaries
        cursor = 0
        for size in (3, 2, 5, len(msg) - 10):
            chunk = msg[cursor:cursor + size]
            if not chunk:
                continue
            ranges.append({
                "kind": "data", "offset_start": offset + cursor,
                "offset_end": offset + cursor + len(chunk), "length": len(chunk),
                "value_hex": chunk.hex(), "provenance": prov(frame_no),
            })
            timestamp = 1791628200.134 + (frame_no - 1) * 0.002
            frame_specs.append({
                "frame_no": frame_no, "timestamp": timestamp,
                "src_ip": "10.77.0.10", "src_port": 42010,
                "dst_ip": "10.77.0.20", "dst_port": 46123,
                "direction": 0,
            })
            frame_no += 1
            cursor += len(chunk)
        offset += len(msg)
    return {
        "schema_version": "0.1",
        "capture": {"capture_id": "cap-123", "source_name": "01_configuration.pcap", "source_path": "sample_protocol/research/01_configuration.pcap"},
        "sessions": [{
            "session_id": "session-1", "initiator": "A",
            "endpoint_a": {"ip": "10.77.0.10", "port": 42010},
            "endpoint_b": {"ip": "10.77.0.20", "port": 46123},
            "diagnostics": [], "packets": frame_specs,
            "directions": [{"direction": 0, "stream": {"status": "ok", "ranges": ranges, "diagnostics": []}}],
        }],
    }


def make_journal():
    starts = [0.134, 0.142, 0.150]
    params = [
        {"enabled": True, "period_ms": 1000, "threshold_c": 21, "label": "Lab"},
        {"enabled": True, "period_ms": 1000, "threshold_c": 19, "label": "Lab"},
        {"enabled": False, "period_ms": 1000, "threshold_c": 21, "label": "Lab"},
    ]
    base = 1791628200.0
    def iso(t):
        from datetime import datetime, timezone
        return datetime.fromtimestamp(base + t, timezone.utc).isoformat().replace("+00:00", "Z")
    return [{
        "capture": "research/01_configuration.pcap", "session": "s1",
        "action_id": ["01-01-002", "01-01-004", "01-01-007"][i], "start_utc": iso(starts[i]),
        "end_utc": iso(starts[i] + 0.007), "action": "set-config",
        "parameters": params[i], "observed_result": {"status": "ok"},
    } for i in range(3)]


def test_extracts_frames_from_chunked_stream_ranges():
    parsed = extract_messages(make_report())
    assert parsed["summary"]["messages_total"] == 3
    assert parsed["messages"][0]["hex_data"].startswith("A6 5C 00 09")
    assert parsed["messages"][0]["byte_length"] == 17
    assert parsed["messages"][0]["direction"] == "client_to_device"


def test_gap_breaks_runs_and_is_never_filled_with_zeros():
    report = make_report()
    ranges = report["sessions"][0]["directions"][0]["stream"]["ranges"]
    ranges.insert(2, {"kind": "gap", "offset_start": 5, "offset_end": 7, "length": 2, "value": None, "provenance": []})
    parsed = extract_messages(report)
    assert any(d["kind"] == "gap" for d in parsed["diagnostics"])


def test_associates_messages_to_journal_by_time_and_capture():
    messages = extract_messages(make_report())["messages"]
    associated = associate_actions(messages, make_journal())
    assert associated[0]["action_matches"]
    assert associated[0]["action_matches"][0]["action"] == "set-config"


def test_numeric_and_boolean_hypotheses_find_known_offsets():
    messages = associate_actions(extract_messages(make_report())["messages"], make_journal())
    candidates = generate_hypothesis_candidates(messages)
    period = [c for c in candidates if c["field"] == "period_ms" and c["kind"] == "numeric"]
    assert any(c["offset"] == 9 and c["width"] == 2 and c["byte_order"] == "big" and c["scale"] == 1 and c["support_count"] == 3 for c in period)
    threshold = [c for c in candidates if c["field"] == "threshold_c" and c["kind"] == "numeric"]
    assert any(c["offset"] == 11 and c["width"] == 2 and c["scale"] == 100 and c["support_count"] == 3 for c in threshold)
    enabled = [c for c in candidates if c["field"] == "enabled" and c["kind"] == "boolean"]
    assert any(c["offset"] == 8 and c["support_count"] == 3 for c in enabled)


def test_text_hypothesis_finds_utf8_and_length_prefix():
    messages = associate_actions(extract_messages(make_report())["messages"], make_journal())
    candidates = generate_hypothesis_candidates(messages)
    label = [c for c in candidates if c["field"] == "label" and c["kind"] == "text"]
    assert any(c["offset"] == 14 and c["length_prefix_offset"] == 13 and c["support_count"] == 3 for c in label)


def test_conflicting_range_is_not_parsed_as_message_bytes():
    report = make_report()
    ranges = report["sessions"][0]["directions"][0]["stream"]["ranges"]
    ranges[1] = {"kind": "conflict", "offset_start": 3, "offset_end": 5, "length": 2, "alternatives": [], "provenance": []}
    parsed = extract_messages(report)
    assert any(d.get("kind") == "conflict" for d in parsed["diagnostics"])


def test_verify_candidate_reports_partial_or_full_support():
    messages = associate_actions(extract_messages(make_report())["messages"], make_journal())
    candidates = generate_hypothesis_candidates(messages)
    period = next(c for c in candidates if c["field"] == "period_ms" and c["kind"] == "numeric" and c["offset"] == 9 and c["width"] == 2 and c["byte_order"] == "big" and not c["signed"] and c["scale"] == 1)
    from madrigal_research.engine import verify_candidate
    result = verify_candidate(period, messages)
    assert result["status"] == "supported_on_supplied_samples"
    assert result["support_count"] == 3


def test_main_analysis_returns_json_serializable_result():
    import json
    from madrigal_research import analyze_capture_report

    result = analyze_capture_report(make_report(), make_journal())
    assert result["summary"]["messages_total"] == 3
    assert result["summary"]["hypothesis_candidates_total"] > 0
    json.dumps(result)  # backend должен иметь возможность вернуть это как JSON


def test_hypothesis_store_crud_and_check_history(tmp_path):
    from madrigal_research.store import append_check, delete_hypothesis, list_hypotheses, save_hypothesis, update_hypothesis
    path = tmp_path / "hypotheses.json"
    candidate = {"candidate_id": "H-123", "field": "period_ms", "kind": "numeric", "offset": 9, "width": 2, "byte_order": "big", "signed": False, "scale": 1}
    saved = save_hypothesis(path, candidate, "Period field", "Testing candidate")
    duplicate = save_hypothesis(path, candidate, "Period field", "Testing candidate")
    assert saved["hypothesis_id"] == duplicate["hypothesis_id"]
    assert len(list_hypotheses(path)) == 1
    updated = update_hypothesis(path, saved["hypothesis_id"], notes="Checked on extra sample")
    assert updated["notes"] == "Checked on extra sample"
    appended = append_check(path, saved["hypothesis_id"], {"status": "supported_on_supplied_samples", "support_count": 3})
    assert len(appended["checks"]) == 1
    assert delete_hypothesis(path, saved["hypothesis_id"]) is True
    assert list_hypotheses(path) == []
