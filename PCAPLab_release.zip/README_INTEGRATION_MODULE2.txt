PCAP LAB — ПОДКЛЮЧЕНИЕ МОДУЛЯ УЧАСТНИКА № 2

В архиве:
- main.py — интеграционная версия FastAPI с эндпоинтом анализа протокола;
- madrigal_research/ — готовый пакет участника № 2;
- tests/test_hypothesis_engine.py — тесты модуля № 2.

ПЕРЕД УСТАНОВКОЙ
1. Останови сервер (Ctrl+C в PowerShell).
2. В папке C:\Users\Милана\hackaton скопируй текущий main.py в main_before_module2.py.
3. Распакуй архив в корень C:\Users\Милана\hackaton, сохраняя структуру каталогов. Разреши замену main.py после создания резервной копии.
4. Проверь, что папки main.py, madrigal_net и madrigal_research находятся на одном уровне.
5. Папку .venv из архива создавать или заменять не нужно.

ПРОВЕРКА МОДУЛЯ № 2
Из PowerShell в корне проекта:
  .\.venv\Scripts\python.exe -m pytest tests\test_hypothesis_engine.py -q
Ожидается: 9 passed.

ЗАПУСК
  .\.venv\Scripts\python.exe -m uvicorn main:app --reload
Открой http://127.0.0.1:8000/docs

СКВОЗНОЙ ТЕСТ В SWAGGER
1. Вызови POST /api/v1/captures и загрузи PCAP, например
   sample_protocol/research/01_configuration.pcap.
2. Скопируй capture_id из ответа.
3. Вызови POST /api/v1/captures/{capture_id}/protocol-analysis.
   Вставь capture_id и приложи соответствующий action_journal.csv.
4. В результате проверь protocol_analysis.summary:
   - messages_total
   - messages_with_action_matches
   - hypothesis_candidates_total
   - diagnostics_total

Важно:
- Используй CSV-журнал именно для выбранного PCAP: модуль сопоставляет строки
  по имени захвата и пересечению временных интервалов.
- Если анализ вернул ноль совпадений, это не обязательно означает ошибку;
  сначала проверь, что capture в CSV совпадает с именем загруженного PCAP и
  что формат/значения времени корректны.
- Статус protocol_research станет connected после успешного вызова анализа.
- Обработанные захваты и результаты остаются в памяти и пропадают при
  перезапуске сервера — это текущее ограничение MVP.
- Модуль участника № 3 пока не подключён.
