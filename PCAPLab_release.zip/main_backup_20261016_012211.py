
from fastapi import FastAPI

app = FastAPI(
    title="PCAP/PCAPNG Protocol Laboratory",
    description=(
        "Integration API for connecting network analysis, "
        "protocol research and validation modules."
    ),
    version="0.1.0",
)

# Статусы подключения модулей команды.
# Пока другие участники не подключены, не выдаём их
# функциональность за уже реализованную.
MODULES = {
    "network_analysis": {
        "owner": "participant_1",
        "status": "not_connected",
    },
    "protocol_research": {
        "owner": "participant_2",
        "status": "not_connected",
    },
    "validation": {
        "owner": "participant_3",
        "status": "not_connected",
    },
}


@app.get("/", tags=["System"])
def root():
    return {
        "message": "Protocol Laboratory Integration API",
        "version": app.version,
        "docs": "/docs",
    }


@app.get("/api/v1/health", tags=["System"])
def health():
    return {
        "status": "ok",
        "service": "integration-api",
        "version": app.version,
    }


@app.get("/api/v1/integration/status", tags=["Integration"])
def integration_status():
    return {
        "status": "in_progress",
        "modules": MODULES,
    }
