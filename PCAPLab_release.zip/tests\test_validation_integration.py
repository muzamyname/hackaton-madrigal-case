import unittest

from validation_integration import validate_protocol_analysis


class ValidationIntegrationTests(unittest.TestCase):
    def setUp(self):
        # The two-byte scale=100 numeric field encodes 21 as 2100 (0x0834).
        # The text field is prefixed by a one-byte UTF-8 byte length.
        self.message = {
            "message_id": "msg-1",
            "direction": "client_to_device",
            "source_frames": [4, 6, 8],
            "hex_data": "A6 5C 00 07 00 01 00 20 01 08 34 03 4C 61 62",
        }

    def test_numeric_boolean_and_text_evidence_are_checked(self):
        analysis = {
            "messages": [self.message],
            "hypothesis_candidates": [
                {
                    "candidate_id": "H-number", "title": "threshold", "field": "threshold_c",
                    "kind": "numeric", "offset": 9, "width": 2, "scale": 100,
                    "byte_order": "big", "strength": "strong", "support_rate": 1,
                    "evidence": [{"message_id": "msg-1", "action_id": "a1", "expected": 21, "observed": 21, "matches": True}],
                },
                {
                    "candidate_id": "H-bool", "title": "enabled", "field": "enabled",
                    "kind": "boolean", "offset": 8, "width": 1, "strength": "strong", "support_rate": 1,
                    "evidence": [{"message_id": "msg-1", "action_id": "a1", "expected": True, "observed": True, "matches": True}],
                },
                {
                    "candidate_id": "H-text", "title": "label", "field": "label",
                    "kind": "text", "offset": 12, "length_prefix_offset": 11,
                    "strength": "strong", "support_rate": 1,
                    "evidence": [{"message_id": "msg-1", "action_id": "a1", "expected": "Lab", "observed_hex": "4C 61 62", "matches": True}],
                },
            ],
        }
        result = validate_protocol_analysis(
            analysis, source_id="sample.pcap", source_sha256="a" * 64
        )
        self.assertEqual(result["summary"]["candidates_total"], 3)
        self.assertEqual(result["summary"]["candidate_evidence_checked"], 3)
        self.assertEqual(result["summary"]["evidence_PASS"], 3)
        self.assertEqual(result["summary"]["evidence_FAIL"], 0)

    def test_mismatch_is_reported_as_fail(self):
        analysis = {
            "messages": [self.message],
            "hypothesis_candidates": [{
                "candidate_id": "H-wrong", "title": "wrong boolean", "field": "enabled",
                "kind": "boolean", "offset": 8, "width": 1,
                "evidence": [{"message_id": "msg-1", "action_id": "a1", "expected": False}],
            }],
        }
        result = validate_protocol_analysis(
            analysis, source_id="sample.pcap", source_sha256="b" * 64
        )
        self.assertEqual(result["summary"]["evidence_FAIL"], 1)
        self.assertEqual(result["candidate_results"][0]["evidence"][0]["checks"][0]["observed"], 1)

    def test_missing_message_is_skipped_with_diagnostic(self):
        analysis = {
            "messages": [],
            "hypothesis_candidates": [{
                "candidate_id": "H-missing", "field": "n", "kind": "numeric", "offset": 0,
                "width": 1, "evidence": [{"message_id": "missing", "expected": 1}],
            }],
        }
        result = validate_protocol_analysis(
            analysis, source_id="sample.pcap", source_sha256="c" * 64
        )
        self.assertEqual(result["summary"]["candidate_evidence_skipped"], 1)
        self.assertEqual(result["diagnostics"][0]["code"], "candidate_evidence_message_missing")

    def test_invalid_source_hash_is_rejected(self):
        with self.assertRaises(ValueError):
            validate_protocol_analysis({}, source_id="sample.pcap", source_sha256="not-a-hash")


if __name__ == "__main__":
    unittest.main()
